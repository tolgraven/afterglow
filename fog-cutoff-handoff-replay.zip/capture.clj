(require '[afterglow.output.scheduler :as scheduler]
         '[afterglow.render.frame :as render]
         '[clojure.data.json :as json]
         '[clojure.pprint :as pprint])

(let [[revision expected-off-time output-prefix] *command-line-args*
      now (atom 0)
      receipts (atom [])
      preparations (atom [])
      copy-window (atom nil)
      fixtures [{:id :wash :universe 1 :address 1 :channels {:dimmer 1}}
                {:id :pump :universe 1 :address 2 :channels {:fog 1}
                 :fogger {:flow-m3-min 60 :dmx-range [196 0]}}]
      patch (render/compile-patch fixtures)
      off-byte (get (:fog-off-bytes patch) [1 1])
      lease {:until-ms 26 :off-byte off-byte}
      bytes-for-report (fn [^bytes channels]
                         {:dimmer (bit-and 255 (aget channels 0))
                          :fog (bit-and 255 (aget channels 1))})
      owner (scheduler/create
             {:now-ms #(deref now)
              :send! (fn [universes id]
                       (swap! receipts conj (assoc (bytes-for-report (get universes 1))
                                                   :at-ms @now :frame-id id :universe 1)))
              :prepare-output (fn [universes {:keys [safety-state]}]
                                (let [^bytes channels (get universes 1)
                                      before (bytes-for-report channels)]
                                  (when (>= @now (:until-ms safety-state))
                                    (aset-byte channels 1 (unchecked-byte (:off-byte safety-state))))
                                  (swap! preparations conj {:at-ms @now :before before
                                                           :after (bytes-for-report channels)})
                                  universes))
              :prepare-safety-output (fn [_ _] nil)
              :output-valid-until-ms (fn [{:keys [safety-state]} checked-at]
                                       (when (< checked-at (:until-ms safety-state))
                                         (:until-ms safety-state)))})
      wire-snapshot (ns-resolve 'afterglow.output.scheduler 'wire-snapshot)
      copy @wire-snapshot]
  (try
    (let [channels (get (render/idle-universes patch) 1)
          frame (scheduler/begin-frame! owner 0 patch {} false)]
      (aset-byte ^bytes channels 0 (unchecked-byte 160))
      (aset-byte ^bytes channels 1 (unchecked-byte 180))
      (assert (scheduler/complete! owner frame {:universes {1 channels} :safety-state lease}))
      (scheduler/publish! owner 0)
      (reset! now 25)
      (with-redefs-fn {wire-snapshot (fn [source buffers]
                                     (let [detached (copy source buffers)]
                                       (when (= @now 25)
                                         (reset! now 27)
                                         (reset! copy-window {:start-ms 25 :end-ms 27}))
                                       detached))}
        #(scheduler/publish! owner 25))
      (reset! now 50)
      (scheduler/publish! owner 50))
    (let [first-off (some #(when (= off-byte (:fog %)) (:at-ms %)) @receipts)
          result {:revision revision :period-ms 25 :lease lease :copy-window @copy-window
                  :first-off-at-ms first-off :receipt @receipts :preparation @preparations}]
      (assert (= (parse-long expected-off-time) first-off) (pr-str result))
      (assert (= [0 27 50] (mapv :at-ms @receipts)) (pr-str result))
      (assert (every? #(= 160 (:dimmer %)) @receipts) (pr-str result))
      (spit (str output-prefix ".edn") (with-out-str (pprint/pprint result)))
      (spit (str output-prefix ".json") (json/write-str result)))
    (finally (scheduler/close! owner))))
