# Fog cutoff during the final frame copy

Both runs use the same Afterglow output scheduler entry points, fixture patch, source packet and injected clock. The scheduler clones the packet for its private wire snapshot. The replay advances the clock from 25 ms to 27 ms as that snapshot returns, crossing the 26 ms pump lease. The ordinary output slot stays eligible until 50 ms.

The capture sink records byte 180 on universe 1, channel 2 at the baseline’s 27 ms handoff. The guarded revision repeats preparation with the updated clock and sends the configured physical off byte, 196, at 27 ms. The baseline sends 196 at 50 ms. The dimmer on channel 1 sends byte 160 throughout. This is a virtual-clock memory-capture result.

| Source | First off handoff |
| --- | ---: |
| Afterglow `64c3cbff3d9e4432871dbdfa2a49bbc04c69d304` | 50 ms |
| Afterglow `a6102b03c688dd301f0d67f04911e78dfb48bb36` | 27 ms |

## Reproduce

Use two Afterglow checkouts at the exact revisions above, Leiningen with the project dependencies cached, and Python with Matplotlib and Pillow installed. Run from the extracted archive.

```sh
bash reproduce.sh /path/to/baseline-afterglow /path/to/guarded-afterglow
```

`capture.clj` sets up the fixture packet, injects the copy interval and records the actual sink callbacks in EDN and JSON. `render.py` draws the PNG and GIF from the JSON receipts. The GIF uses a slower playback rate so the copy, expiry and send can be read. `afterglow-parity.log` contains the full parity run on the guarded commit.
