#!/usr/bin/env bash
set -euo pipefail

artifact_dir=$(cd -- "$(dirname -- "$0")" && pwd)
baseline=$(realpath -- "${1:?Pass the baseline Afterglow checkout}")
guarded=$(realpath -- "${2:?Pass the guarded Afterglow checkout}")
lein_bin=${LEIN_BIN:-lein}

capture() {
  local checkout=$1 revision=$2 expected_off_time=$3 artifact_prefix=$4
  (
    cd -- "$checkout"
    test "$(git rev-parse HEAD)" = "$revision"
    args=(-o run -m clojure.main "$artifact_dir/capture.clj"
          "$revision" "$expected_off_time" "$artifact_dir/$artifact_prefix")
    "$lein_bin" "${args[@]}"
  )
}

capture "$baseline" 64c3cbff3d9e4432871dbdfa2a49bbc04c69d304 50 baseline
capture "$guarded" a6102b03c688dd301f0d67f04911e78dfb48bb36 27 guarded
MPLCONFIGDIR="${MPLCONFIGDIR:-$(mktemp -d)}" python3 "$artifact_dir/render.py"
