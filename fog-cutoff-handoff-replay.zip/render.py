"""Plot the two observed scheduler runs. Requires Matplotlib and Pillow."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image


HERE = Path(__file__).resolve().parent
BG = "#0e1724"
PANEL = "#152232"
GRID = "#34465a"
TEXT = "#f2f6fc"
MUTED = "#b7c5d6"
FAINT = "#8295ac"
AMBER = "#f6bd72"
MINT = "#83e1cd"
LEASE = "#e2ca88"
START, END = 22, 52

baseline = json.loads((HERE / "baseline.json").read_text())
guarded = json.loads((HERE / "guarded.json").read_text())
assert baseline["lease"] == guarded["lease"]
assert baseline["copy-window"] == guarded["copy-window"]
cutoff = baseline["lease"]["until-ms"]
off_byte = baseline["lease"]["off-byte"]
copy_window = baseline["copy-window"]
baseline_off = baseline["first-off-at-ms"]
guarded_off = guarded["first-off-at-ms"]
actual_handoff = guarded_off


def trace(ax, run, inactive, label, color, cursor):
    active = inactive + 0.50
    positions = {True: active, False: inactive}
    receipts = run["receipt"]
    warm = next(receipt for receipt in reversed(receipts) if receipt["at-ms"] <= START)
    shown = [receipt for receipt in receipts if START < receipt["at-ms"] <= cursor]
    times = [START, *(row["at-ms"] for row in shown), cursor]
    states = [positions[row["fog"] != off_byte] for row in [warm, *shown]]
    ax.step(times, [*states, states[-1]], where="post", color=color, linewidth=3.0, zorder=4)
    for row in shown:
        x_pos = row["at-ms"]
        y_pos = positions[row["fog"] != off_byte]
        ax.scatter(x_pos, y_pos, s=67, color=color, edgecolor=BG, linewidth=0.9, zorder=5)
        ax.annotate(
            f"DMX {row['fog']}",
            xy=(x_pos, y_pos),
            xytext=((-12 if x_pos > 47 else 10), 9),
            textcoords="offset points",
            ha="right" if x_pos > 47 else "left",
            va="bottom",
            color=color,
            size=10.5,
            weight="bold",
            zorder=6,
        )
    fig = ax.figure
    center_y = fig.transFigure.inverted().transform(ax.transData.transform((START, inactive + .25)))[1]
    fig.text(.054, center_y + .008, label, color=TEXT, size=16.3, weight="bold")
    fig.text(.054, center_y - .027, run["revision"][:8], color=FAINT, size=11, family="DejaVu Sans Mono")
    for y_pos, state in [(active, "FLOW"), (inactive, "OFF")]:
        ax.axhline(y_pos, color=GRID, linewidth=1.0, linestyle=(0, (3, 4)), zorder=1)
        ax.text(START - .55, y_pos, state, color=FAINT, size=9, ha="right", va="center", clip_on=False)


def metric(fig, x_pos, value, label, color):
    fig.text(x_pos, .153, value, color=color, size=24, weight="bold")
    fig.text(x_pos, .111, label, color=MUTED, size=11.5)


def render(cursor=END, stage=None):
    fig = plt.figure(figsize=(12, 7.2), dpi=110, facecolor=BG)
    fig.text(.054, .947, "AFTERGLOW   /   PHYSICAL OUTPUT REPLAY", color=MINT, size=10.5, weight="bold")
    fig.text(.947, .947, "40 Hz  ·  Virtual clock  ·  Memory sink", color=MUTED, size=10.5, ha="right")
    fig.text(.054, .864, "Fog cutoff during the final frame copy", color=TEXT, size=32, weight="bold")
    fig.text(.054, .812, "Both revisions receive the same source frame and a 2 ms injected copy delay.", color=MUTED, size=13)
    fig.text(
        .054,
        .756,
        stage or "At the 27 ms handoff, guarded output already carries the pump’s configured off byte.",
        color=LEASE if stage else MINT,
        size=11.3,
        weight="bold",
    )

    ax = fig.add_axes((.25, .295, .697, .407), facecolor=PANEL)
    ax.set_xlim(START, END)
    ax.set_ylim(.62, 3.65)
    ax.set_xticks([22, 25, 27, 30, 35, 40, 45, 50])
    ax.set_yticks([])
    ax.tick_params(axis="x", colors=MUTED, length=0, pad=8, labelsize=10)
    for spine in ax.spines.values():
        spine.set_color(GRID)
    ax.grid(axis="x", color=GRID, linewidth=.6, alpha=.48)
    ax.axvspan(copy_window["start-ms"], copy_window["end-ms"], color=LEASE, alpha=.13, zorder=1)
    ax.axvline(cutoff, color=LEASE, linewidth=1.3, linestyle=(0, (4, 3)), zorder=2)
    ax.text(cutoff + .3, 3.50, f"{cutoff} ms lease cutoff", color=LEASE, size=10.6, va="center", weight="bold", zorder=3)
    trace(ax, baseline, 2.48, "Baseline", AMBER, cursor)
    trace(ax, guarded, 1.11, "Guarded", MINT, cursor)
    if cursor < END:
        ax.axvline(cursor, color=TEXT, linewidth=1.0, alpha=.85, zorder=3)
    fig.text(.947, .222, "VIRTUAL CLOCK (ms)", color=MUTED, size=9.2, ha="right", weight="bold")

    metric(fig, .054, f"{baseline_off} ms" if cursor >= baseline_off else "—", "Baseline first sends off", AMBER)
    metric(fig, .358, f"{guarded_off} ms" if cursor >= guarded_off else "—", "Guarded first sends off", MINT)
    metric(fig, .662, f"{baseline_off - guarded_off} ms" if cursor >= baseline_off else "—", "Earlier off delivery in this replay", TEXT)
    fig.text(
        .054, .045,
        f"Universe 1  ·  Fog on channel 2  ·  Configured off byte {off_byte}  ·  Dimmer on channel 1 stays at DMX 160",
        color=FAINT, size=10.7,
    )
    return fig


def gif_frame(cursor, stage):
    fig = render(cursor, stage)
    fig.canvas.draw()
    frame = Image.frombytes("RGBA", fig.canvas.get_width_height(), bytes(fig.canvas.buffer_rgba()))
    plt.close(fig)
    return frame.convert("RGB").resize((1100, 660), Image.Resampling.LANCZOS)


still = render()
still.savefig(HERE / "fog-cutoff-handoff.png", facecolor=BG)
plt.close(still)

sequence = [
    (22, "Both revisions hold the previously sent flow request.", 550),
    (23, "Both revisions hold the previously sent flow request.", 130),
    (24, "Both revisions hold the previously sent flow request.", 130),
    (25, "25 ms · Both revisions prepare the same source frame.", 700),
    (26, "26 ms · The pump lease expires during the private copy.", 850),
    (actual_handoff, "27 ms · The guarded scheduler repeats preparation and sends off.", 1450),
    *[(tick, "The guarded output is off. The baseline still holds the flow request.", 100)
      for tick in range(29, 50, 2)],
    (baseline_off, "50 ms · The baseline sends off at the next 40 Hz slot.", 1100),
    (END, "The guarded scheduler sends off 23 ms earlier in this virtual-clock replay.", 1700),
]
frames = [gif_frame(cursor, stage) for cursor, stage, _ in sequence]
frames[0].save(
    HERE / "fog-cutoff-handoff.gif",
    save_all=True,
    append_images=frames[1:],
    duration=[duration for _, _, duration in sequence],
    loop=0,
    optimize=True,
)
