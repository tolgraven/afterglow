#!/usr/bin/env bash
set -eu
: "${TOLGLOW_ROOT:?set to paired Tolglow checkout at 39defcc0}"
: "${AFTERGLOW_ROOT:?set to merged Afterglow checkout or the PR head}"
capture_dir=$(cd "$(dirname "$0")" && pwd)
capture_cp=$(cd "$TOLGLOW_ROOT" && lein with-profile +benchmark classpath)
for pixels in 10000 20000; do
  java -Xmx1800m -XX:ActiveProcessorCount=3 -cp "$capture_dir:$capture_cp" clojure.main \
    "$capture_dir/paired-final.clj" "$capture_dir/result-$pixels.edn" \
    "$capture_dir/perf/baseline.clj" "$capture_dir/perf/final.clj" "$pixels" 18 32
done
