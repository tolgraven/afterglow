(require '[afterglow.render.presentation :as p] '[perf.scalar-check :as q])
(import '[java.lang.management ManagementFactory] '[com.sun.management ThreadMXBean])
(def ^ThreadMXBean counter (ManagementFactory/getThreadMXBean))
(defn measure [f x]
  (let [bytes (.getCurrentThreadAllocatedBytes counter) cpu (.getCurrentThreadCpuTime counter) time (System/nanoTime)
        result (f x)]
    [result {:ms (/ (- (System/nanoTime) time) 1e6)
             :cpu (/ (- (.getCurrentThreadCpuTime counter) cpu) 1e6)
             :bytes (- (.getCurrentThreadAllocatedBytes counter) bytes)}]))
(defn trial [x i]
  (let [functions [#'p/immutable-universes #'q/immutable-universes]
        order (if (even? i) [0 1] [1 0])
        vals (into {} (for [j order] [j (measure (functions j) x)]))]
    (assert (= (first (vals 0)) (first (vals 1))))
    (mapv (comp second vals) [0 1])))
(let [mm (into {} (for [id (range 158)] [id (mapv #(bit-and 255 (+ id %)) (range 512))]))]
  (dotimes [i 32] (trial mm i))
  (spit (first *command-line-args*) (pr-str (mapv (partial trial mm) (range 32 88)))))
