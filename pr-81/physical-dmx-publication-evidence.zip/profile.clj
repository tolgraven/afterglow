(require '[tolglow.bench-show :as b] '[tolglow.show :as show] '[afterglow.render.presentation :as p]
         '[perf.scalar-check :as q])
(import '[java.lang.management ManagementFactory] '[com.sun.management ThreadMXBean] '[jdk.jfr Recording] '[java.nio.file Paths])
(def ^ThreadMXBean counter (ManagementFactory/getThreadMXBean))
(defn observe [f x]
  (let [bytes (.getCurrentThreadAllocatedBytes counter) cpu (.getCurrentThreadCpuTime counter) time (System/nanoTime)
        result (f x)]
    [result {:ms (/ (- (System/nanoTime) time) 1e6)
             :cpu (/ (- (.getCurrentThreadCpuTime counter) cpu) 1e6)
             :bytes (- (.getCurrentThreadAllocatedBytes counter) bytes)}]))
(let [{:keys [model preview-indices]} (b/corpus 20000 64 :sculpture) clock (volatile! 0)
      sink (b/capture-sink)
      runtime (show/create-runtime {:model model :workspace-options nil :physical-now-ms #(deref clock)
                                    :workers 2 :sink sink :independent-output? true})
      src @#'p/immutable-universes
      candidate @#'q/immutable-universes
      current (volatile! {})
      rows (volatile! [])
      run (fn [i] (b/projected-host-step! runtime sink clock preview-indices i))
      capt (fn [u] (let [[result counts] (observe src u)
                         row (val (first u)) k (if (vector? row) :vector :array)]
                     (vswap! current assoc k u) (vswap! rows conj (assoc counts :kind k)) result))]
  (try
    (with-redefs-fn {#'p/immutable-universes capt} #(dotimes [i 50] (run i)))
    (let [^Recording recorder (Recording.)
          check (fn [i]
                  (into {} (for [k [:array :vector]
                                 [label f] (if (odd? i) [[:baseline src] [:candidate candidate]] [[:candidate candidate] [:baseline src]])]
                             [[k label] (second (observe f (get @current k)))])))]
      (.enable recorder "jdk.ObjectAllocationSample")
      (.start recorder)
      (spit "/tmp/venue-publish-actual-guard.edn"
            (pr-str {:calls @rows :rows (mapv check (range 96))}))
      (.stop recorder) (.dump recorder (Paths/get "/tmp/venue-publish-actual.jfr" (into-array String []))) (.close recorder))
    (finally (show/stop! runtime))))
(shutdown-agents)
