(require '[clojure.edn :as edn] '[afterglow.render.presentation :as p]
         '[tolglow.bench-show :as b] '[tolglow.show :as show])
(import '[java.lang.management ManagementFactory] '[com.sun.management ThreadMXBean]
        '[java.security MessageDigest] '[java.util HexFormat])

(defn worker-observation [counter task]
  (let [allocated (:allocated counter) cpu (:cpu counter) bytes (allocated) before-cpu (cpu)
        start (System/nanoTime) result (task)]
    [result {:wall-ms (/ (- (System/nanoTime) start) 1e6)
             :cpu-ms (/ (- (cpu) before-cpu) 1e6) :bytes (- (allocated) bytes)
             :tick-ms (get-in result [:stages-ms :tick])
             :publish-ms (get-in result [:stages-ms :publish])}]))

(defn make-host [model options]
  (let [clock (volatile! 0.0) sink (b/capture-sink)]
    {:clock clock :sink sink
     :runtime (show/create-runtime (merge {:model model :workspace-options nil
                                           :physical-now-ms #(deref clock)
                                           :worker-timeout-ms 10000}
                                          options {:sink sink}))}))

(defn step [host indices i]
  (b/projected-host-step! (:runtime host) (:sink host) (:clock host) indices i))

(defn trace [result]
  (let [digest (MessageDigest/getInstance "SHA-256")]
    (doseq [^bytes packet (:packets result)] (.update digest packet))
    (.formatHex (HexFormat/of) (.digest digest))))

(let [[output baseline-script candidate-script pixels warmup samples] *command-line-args*
      pixels (parse-long pixels) warmup (parse-long warmup) samples (parse-long samples)
      _ (load-file baseline-script)
      _ (load-file candidate-script)
      base (ns-resolve 'perf.baseline 'immutable-universes) candidate (ns-resolve 'perf.candidate 'immutable-universes)
      {:keys [model preview-indices]} (b/corpus pixels 64 :sculpture)
      oracle (make-host model {:batch? false :workers 1})
      hosts (zipmap [:baseline :candidate] (repeatedly 2 #(make-host model {:independent-output? true :workers 2})))
      run (fn [sources id i] (with-redefs-fn {#'p/immutable-universes (get sources id)}
                               #(step (get hosts id) preview-indices i)))
      sources {:baseline @base :candidate @candidate}
      expected (try (mapv #(step oracle preview-indices %) (range (+ warmup samples)))
                    (finally (show/stop! (:runtime oracle))))]
  (try
    (dotimes [i warmup] (doseq [id (keys hosts)] (b/check! (expected i) (run sources id i))))
    (let [counters (#'b/worker-counters)
          rows (mapv (fn [i]
                       (let [order (if (even? i) [:baseline :candidate] [:candidate :baseline])
                             results (into {} (for [id order] [id (worker-observation counters #(run sources id i))]))
                             physical (fn [id] (first (results id)))
                             a (physical :baseline) b (physical :candidate)]
                         (b/check! (expected i) a) (b/check! (expected i) b) (b/check! a b)
                         {:i i :order order :artdmx (trace a) :universes (count (:packets a))
                          :baseline (second (results :baseline)) :candidate (second (results :candidate))}))
                     (range warmup (+ warmup samples)))]
      (spit output (pr-str {:pixels pixels :movers 64 :warmup warmup :observations rows})))
    (finally (doseq [[_ host] hosts] (show/stop! (:runtime host))))))
(shutdown-agents)
