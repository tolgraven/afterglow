(require '[clojure.edn :as edn])
(defn pct [p xs] (nth (vec (sort xs)) (dec (long (Math/ceil (* (count xs) p))))))
(doseq [file *command-line-args*]
  (let [data (edn/read-string (slurp file)) rows (:observations data)]
    (prn (:pixels data) (count rows) (mapv :universes (take 1 rows)))
    (doseq [lane [:baseline :candidate]]
      (prn lane (into {} (for [field [:bytes :cpu-ms :wall-ms :publish-ms]]
                           [field (mapv #(pct % (map (comp field lane) rows)) [0.50 0.95])]))
           :over25 (count (filter #(> (get-in % [lane :wall-ms]) 25) rows))))))
