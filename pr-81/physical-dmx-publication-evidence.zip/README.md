# Measuring physical frame publication

Tolglow 39defcc0cbc65d216a806a7ca818f6895df3f4aa hosts the same 3D sculpture and moving-head effects on three independent show runtimes. The Afterglow compiler and engine are from 251a180e78ddfb4d20875225d384caf09e8a2b0b. The two measured hosts dispatch into that commit’s packet functions or the replacement functions in 4769e27c4b803c7a4a9f8ed9cd010ae5ddc0039b. Their sources are in perf/ with benchmark-only namespace names. Both hosts use two renderer workers and the independent physical publisher. A third, single-worker host uses the scalar compiler and direct output as the oracle.

Each of the 18 warmup and 32 timed frames checks all ArtDMX packets, committed model, effect intents and selected preview coordinates/colors to the Tolglow benchmark’s 1e-9 tolerance. The measured order alternates by frame. Each timed row includes a SHA-256 over all of that frame’s fully encoded universes. Worker and coordinator allocation/cpu counters cover the two runtime workers and the measurement thread (other idle runtime workers are sampled, too). Physical time is injected and advanced by 25 ms. Network and physical interfaces are not opened. Nearest-rank p50 and p95 use the convention in tolglow.bench-show.

Set TOLGLOW_ROOT and AFTERGLOW_ROOT to the two checkouts, make Leiningen available on PATH and run:

    bash replay.sh

These captures were produced with OpenJDK 21 on a shared Linux x86_64 VM. Other compilation and tests ran during some of the measurements. Measurements isolate publication work but do not establish real-hardware asynchronous jitter, I/O timing or a guarantee of 40 Hz.

The source-attribution and microbenchmark files preserve a deliberately incomplete first optimization (input validation only) along with both zero-equivalent and favorable allocation scenarios. In particular, the first-stage 20k full-show p95 has two high outliers in the change and rises to 174 ms. Mixed byte array and vector inputs expose allocation more reliably than a JVM trained only on immutable vectors. The final comparison adds the direct primitive transport store and uses both complete sources.

The replay only needs paired-final.clj, perf/baseline.clj and perf/final.clj. Other EDNs and the CSV record earlier runs and input controls. The standalone report.clj accepts EDN paths and runs with Babashka or Clojure.
