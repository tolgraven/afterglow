(ns perf.rows)

(def byte-array-class (class (byte-array 0)))
(defn bad! [id]
  (throw (ex-info "Each universe must contain exactly 512 byte values" {:universe id})))
(defn natural? [x] (and (integer? x) (<= 0 x Long/MAX_VALUE)))

(defn normalized-vector [id values]
  (when-not (= 512 (count values)) (bad! id))
  (loop [i 0 result values]
    (if (= i 512)
      result
      (let [v (nth values i)]
        (when-not (and (integer? v) (<= -128 v) (<= v 255)) (bad! id))
        (recur (inc i)
               (if (neg? (long v)) (assoc result i (bit-and (long v) 255)) result))))))

(def unsigned-by-offset (vec (range 256)))
(defn array-vector [id ^bytes bytes]
  (when-not (= 512 (alength bytes)) (bad! id))
  (loop [i 0 v (transient [])]
    (if (= i 512)
      (persistent! v)
      (recur (inc i) (conj! v (nth unsigned-by-offset (bit-and (aget bytes i) 255)))))))

(defn freeze [universes]
  (when-not (and (map? universes) (every? natural? (keys universes))) (bad! nil))
  (reduce-kv (fn [out id values]
               (assoc out id (cond
                               (bytes? values) (array-vector id values)
                               (vector? values) (normalized-vector id values)
                               :else (bad! id)))) (sorted-map) universes))
