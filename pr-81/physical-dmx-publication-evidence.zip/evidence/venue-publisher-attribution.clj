(require '[tolglow.bench-show :as bench] '[afterglow.output.scheduler :as scheduler]
         '[afterglow.render.presentation :as present])
(import '[java.lang.management ManagementFactory] '[com.sun.management ThreadMXBean])
(def ^ThreadMXBean bean (ManagementFactory/getThreadMXBean))
(def ^:dynamic *costs* nil)
(defn counts [] (.getCurrentThreadAllocatedBytes bean))
(defn observe [f]
  (let [a (counts) c (.getCurrentThreadCpuTime bean) t (System/nanoTime) v (f)
        ms (/ (- (System/nanoTime) t) 1e6)]
    [v {:bytes (- (counts) a) :cpu-ms (/ (- (.getCurrentThreadCpuTime bean) c) 1e6) :ms ms}]))
(defn wrap [f k]
  (fn [& args]
    (if-not *costs* (apply f args)
      (let [[v row] (observe #(apply f args))]
        (swap! *costs* update k (fnil #(merge-with + %1 %2) {}) (assoc row :calls 1))
        v))))
(let [rows (atom {})
      measure bench/measure
      wrapped (fn [run expected {:keys [warmup] :as opts}]
                (let [lane (count @rows)]
                  (swap! rows assoc lane [])
                  (measure (fn [i] (if (< i warmup) (run i)
                                    (let [costs (atom {})
                                          [result total] (binding [*costs* costs] (observe #(run i)))]
                                      (swap! rows update lane conj (assoc @costs :complete-host total :i i))
                                      result))) expected opts)))
      fs {#'present/immutable-universes :immutable-universes #'present/freeze-frame :freeze-frame
          #'present/materialize :materialize #'present/present :present #'present/complete :accept
          #'scheduler/complete! :complete #'scheduler/publish! :publish}
      wrappers (into {#'bench/measure wrapped} (for [[v k] fs] [v (wrap @v k)]))
      corpus (bench/corpus 20000 64 :sculpture)
      opts {:warmup 12 :samples 16 :workers [2]}
      result (with-redefs-fn wrappers #(vec (#'bench/host-bench corpus opts)))]
  (spit (first *command-line-args*) (pr-str {:rows @rows :host result})))
(shutdown-agents)
