(require '[perf.baseline :as baseline] '[perf.candidate :as candidate] '[perf.stores :as stores])
(import '[java.lang.management ManagementFactory] '[com.sun.management ThreadMXBean])
(def ^ThreadMXBean counter (ManagementFactory/getThreadMXBean))
(defn measure [f x]
  (let [bytes (.getCurrentThreadAllocatedBytes counter) cpu (.getCurrentThreadCpuTime counter) time (System/nanoTime)
        result (f x)]
    [result {:ms (/ (- (System/nanoTime) time) 1e6)
             :cpu (/ (- (.getCurrentThreadCpuTime counter) cpu) 1e6)
             :bytes (- (.getCurrentThreadAllocatedBytes counter) bytes)}]))
(defn trial [packet i]
  (let [functions [baseline/materialize candidate/materialize stores/materialize]
        order (if (even? i) [0 1 2] [2 1 0])
        runs (into {} (for [j order] [j (measure (functions j) packet)]))
        universes (map #(get-in runs [% 0 :universes]) [0 1 2])]
    (doseq [[id ^bytes values] (first universes)]
      (doseq [other (rest universes)]
        (assert (java.util.Arrays/equals values ^bytes (get other id)))))
    (mapv #(second (runs %)) [0 1 2])))
(let [packet {:universes (into {} (for [id (range 158)] [id (mapv #(bit-and 255 (+ id %)) (range 512))]))}]
  (dotimes [i 32] (trial packet i))
  (spit (first *command-line-args*) (pr-str (mapv (partial trial packet) (range 32 88)))))
