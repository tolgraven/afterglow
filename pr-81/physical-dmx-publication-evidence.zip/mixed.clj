(require '[afterglow.render.presentation :as p] '[perf.scalar-check :as q] '[perf.rows :as rows])
(import '[java.lang.management ManagementFactory] '[com.sun.management ThreadMXBean])
(def ^ThreadMXBean counter (ManagementFactory/getThreadMXBean))
(defn measure [f x]
  (let [bytes (.getCurrentThreadAllocatedBytes counter) cpu (.getCurrentThreadCpuTime counter) time (System/nanoTime)
        result (f x)]
    [result {:ms (/ (- (System/nanoTime) time) 1e6)
             :cpu (/ (- (.getCurrentThreadCpuTime counter) cpu) 1e6)
             :bytes (- (.getCurrentThreadAllocatedBytes counter) bytes)}]))
(defn trial [x i]
  (let [functions [#'p/immutable-universes #'q/immutable-universes #'rows/freeze]
        order (if (even? i) [0 1 2] [2 1 0])
        vals (into {} (for [j order] [j (measure (functions j) x)]))]
    (assert (apply = (map first (map vals [0 1 2]))))
    (mapv (comp second vals) [0 1 2])))
(let [mm (into {} (for [id (range 158)] [id (mapv #(bit-and 255 (+ id %)) (range 512))]))
      arrs (into {} (map (fn [[id row]] [id (byte-array (map unchecked-byte row))]) mm))
      run (fn [i] (if (even? i) {:array (trial arrs i) :vector (trial mm i)} {:vector (trial mm i) :array (trial arrs i)}))]
  (dotimes [i 32] (run i))
  (spit (first *command-line-args*) (pr-str (mapv run (range 32 88)))))
