**None of the 144 CPU show frames or 72 additional GPU-material show frames met the 25 ms deadline.** At 10,000 and 20,000 pixels each implementation ran 36 measured frames after 18 warmup pairs. The four moving spheres select fixture positions and beams, with their influence fading at the edges. The table reports the original and prepared responses. P95 is the 35th-shortest of 36 frames.

| Per frame | 10,000 pixels and 64 heads | 20,000 pixels and 64 heads |
| --- | ---: | ---: |
| Sphere sampling allocation, median (MB) | 13.39 → 10.98 | 21.18 → 19.22 |
| Sphere sampling CPU, median (ms) | 68.29 → 57.24 | 103.09 → 94.80 |
| Sphere sampling CPU, p95 (ms) | 206.41 → 141.46 | 515.59 → 179.84 |
| Whole-show allocation, median (MB) | 33.05 → 30.62 | 63.22 → 61.24 |
| Whole-show elapsed, median (ms) | 479.90 → 399.58 | 197.64 → 179.63 |
| Whole-show elapsed, p95 (ms) | 1,255.09 → 901.55 | 1,189.75 → 1,100.24 |

The same committed state, effect operations, ordered fixture events, preview samples and ArtDMX bytes were verified for every pair. Effects ran on two Clojure workers with JVM material and moving-head evaluation. A capture sink collected the independent output in memory. Elapsed times include scheduler contention on a shared Linux host. The reproducible archive includes the actual per-frame waits and overlapping JVM pauses.

On the 20,000-pixel mixed-material replay, Mesa software OpenGL dispatched 495 times and issued 333 draws per host. Both reported zero fallbacks and read 320,080 bytes on the diagnostic frame. The optimized host allocated **41.95 MB** per median frame versus **46.73 MB** originally. Its median elapsed time was **218.79 ms** versus **200.57 ms** originally. The slow-end elapsed time fell from **595.45 to 368.90 ms**. The underlying ArtDMX digest agreed across CPU and GPU-material execution. This is a software GL integration check on Linux.
