from pathlib import Path
import re,math,sys
def rows(path):
    text=Path(path).read_text()
    raw=text.split(':rows [')[1].split('], :traffic')[0]
    out=[dict((k,float(v)) for k,v in re.findall(r':([a-z0-9-]+)\s+([0-9.eE+-]+)',s)) for s in re.findall(r'\{([^{}]+)\}',raw)]
    return [r for r in out if 'lane' in r]
def percentile(values,q):
    return sorted(values)[math.ceil(len(values)*q)-1]
if __name__=='__main__':
    for p in sys.argv[1:]:
        print(p)
        a=rows(p)
        for lane in (0,1):
            subset=[r for r in a if r['lane']==lane]
            out={k:[round(percentile([r[k] for r in subset],q)/(1e6 if k.endswith('bytes') else 1),3) for q in (.5,.95)] for k in ['ms','field','cpu-ms','bytes','field-bytes','field-cpu-ms','runqueue','gc-pause-ms'] if k in subset[0]}
            print(lane,len(subset),out)
        s=Path(p).read_text()
        print('artdmx',re.search(r':artdmx-sha256 "([^"]+)"',s)[1],'cpu fallback',re.findall(r':cpu-fallbacks (\d+)',s),'draws',re.findall(r':draws (\d+)',s))
