#!/usr/bin/env bash
set -euo pipefail
source_dir=$(cd "$(dirname "$0")" && pwd)
kit=${1:?pass the directory extracted from macbook-air-lighting-benchmark-v2.zip}
output=${2:-"$PWD/field-replay"}
mkdir -p "$output"
output=$(cd "$output" && pwd)
runner="$output/runner"
mkdir -p "$runner"
for source in run.sh platform.clj gpu.clj mixed-material.clj reference-radial.clj; do
  cp "$kit/$source" "$runner/$source"
done
cp "$source_dir/paired.clj" "$runner/paired.clj"
export SPHERE_CANDIDATE="$source_dir/field.clj"
export BENCH_CACHE=${BENCH_CACHE:-"$(cd "$kit" && pwd)/.bench-cache"}
export BENCH_WARMUP=${BENCH_WARMUP:-18} BENCH_SAMPLES=${BENCH_SAMPLES:-36}
for size in 10000 20000; do
  BENCH_PIXELS=$size "$runner/run.sh" cpu "$output/$size.edn"
done
python3 "$source_dir/read-rows.py" "$output/10000.edn" "$output/20000.edn"
if [[ "${BENCH_GPU:-0}" == 1 ]]; then
  BENCH_PIXELS=20000 "$runner/run.sh" gpu-show "$output/gpu-show-20000.edn"
fi
