# Compact fixture emission in a complete show

This CPU replay compares the ordinary compact-to-map reader with the fixed-head emission reader from Afterglow 1a92701. Both paths run the same Tolglow show and compare fixture contacts, show model, effect intents, selected preview and every ArtDMX byte after each sample. Output uses an in-memory capture. Each size uses two show instances, alternating both execution order and physical host.

Use local Git checkouts that contain Tolglow fef01db4 and Afterglow 52db646c, 1a927011, 4769e27, c83375f and 902c0e0. The last three revisions reproduce the independent publication, native-field and validation improvements present in the measured comparison. These are public pull-request revisions. The launcher makes temporary exports and leaves both clones intact. JDK 21 or newer, Leiningen, Git, Bash and patch are required. Allow enough temporary disk space for both project exports and their classpath.

```sh
TOLGLOW_ROOT=/path/to/tolglow AFTERGLOW_ROOT=/path/to/afterglow ./replay.sh ./results
```

Defaults are 18 warmup and 36 measured pairs at 10,000 and 20,000 pixels, each with 64 moving heads, eight washes, four moving spheres and a beat-driven mixed UV material. For a quick functional run set `BENCH_PIXELS=1000 BENCH_WARMUP=2 BENCH_SAMPLES=4`. The EDN report identifies its exact optical sources by SHA-256 and includes per-frame timings and allocation. The adjacent JFR is created on your own machine and contains GC events. Wall-time distributions reflect local contention. No network lighting output or hardware GPU is used.
