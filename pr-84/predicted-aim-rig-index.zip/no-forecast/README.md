The negative control used Tolglow master 00ece48f7470154b056aea26a40713321ebb7924 and the original Afterglow pair in ../revisions.txt. The candidate tree also matches Afterglow master 14abdf9630baba74bbf70029a07609a14686eb01. Run the following from Tolglow in each checkout, using a different output file in baseline/candidate/candidate/baseline order.

```sh
AFTERGLOW_ROOT=/absolute/path/to/afterglow lein with-profile +benchmark run -m clojure.main /absolute/path/to/no-forecast.clj output.edn
```

Each trial launched 32, 128 and 256 distinct effects on 32 dimmers, with two effect workers, full-rate evaluation and no attached displays. All 48 warmup and 80 measured output ticks had no committed forecast. The ArtDMX digest covers all 128 ticks. The position preparer had zero calls in both candidate runs at every size. The isolated authored-key scan reports milliseconds per whole definition scan. It is measured on both checkouts to characterize this one data structure walk separately from the complete coordinator's worker dispatch, show composition and output costs.
