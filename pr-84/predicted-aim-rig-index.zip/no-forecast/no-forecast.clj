(require '[clojure.java.io :as io] '[tolglow.bench-show :as bench]
         '[tolglow.show :as show] '[afterglow.control.model :as control]
         '[afterglow.runtime.keyframes :as kf] '[afterglow.runtime.keyframes.values :as values])
(import '[java.lang.management ManagementFactory ThreadMXBean] '[java.security MessageDigest])
(def ^ThreadMXBean cpu (ManagementFactory/getThreadMXBean))
(defn setup [n]
  (let [rig (mapv (fn [i] {:id (str "lamp-" i) :universe 1 :address (inc i) :channels {:dimmer 1}}) (range 32))]
    (reduce (fn [m i]
              (let [id (keyword (str "effect-" i)) level (/ (inc (mod i 31)) 32.0)
                    defn {:id id :version 1 :targets [(:id (rig (mod i 32)))] :outputs {:dimmer level}}]
                (-> m
                    (bench/command [:publish i] {:op :registry/publish :kind :effects :definition defn})
                    (bench/command [:launch i] {:op :effect/launch :effect-id id}))))
            (control/new-show {:show-id :no-forecast :rig {:fixtures rig}}) (range n))))
(defn reference [id x] (when (not= id x) (throw (ex-info "Wrong active instance count" {:expected id :actual x}))))
(defn capture [m]
  (let [sink (bench/capture-sink) runtime (show/create-runtime {:model m :workers 2 :batch? true
                         :adaptive-keyframes {:enabled? true :max-stride 1} :worker-timeout-ms 15000
                         :sink sink :workspace-options nil})
        n (count (:instances m)) digest (MessageDigest/getInstance "SHA-256") index-calls (atom 0)
        index-var (ns-resolve 'afterglow.runtime.keyframes 'with-rig-positions)
        index (when index-var @index-var)
        sample (fn [i]
                 (vreset! (:latest sink) [])
                 (let [start (.getCurrentThreadCpuTime cpu) t (System/nanoTime)
                       _ (show/tick! runtime (* i 25))
                       elapsed (/ (- (System/nanoTime) t) 1e6)
                       coordinator (/ (- (.getCurrentThreadCpuTime cpu) start) 1e6)
                       state @(:state runtime)]
                   (reference n (count (get-in state [:model :instances])))
                   (when (or (seq (:keyframes state)) (seq (:fault-events state)) (empty? @(:latest sink)))
                     (throw (ex-info "Unexpected window, fault or missing output" {:index i})))
                   (doseq [^bytes packet @(:latest sink)] (.update digest packet))
                   [coordinator elapsed]))
        execute (fn []
                  (dotimes [i 48] (sample i))
                  (let [rows (mapv sample (range 48 128))]
                    {:active n :frames 80 :workers 2 :keyframe-index-preparations (when index @index-calls)
                     :coordinator-cpu-ms (bench/distribution (map first rows))
                     :tick-wall-ms (bench/distribution (map second rows))
                     :artdmx-sha256 (.formatHex (java.util.HexFormat/of) (.digest digest))}))]
    (try (if index (with-redefs-fn {index-var (fn [frame] (swap! index-calls inc) (index frame))} execute) (execute))
         (finally (show/stop! runtime)))))
(defn probe-scan [m]
  (let [defs (vals (get-in m [:registry :effects]))]
    (dotimes [_ 100] (dotimes [_ 20] (some :keyframes defs)))
    (bench/distribution (repeatedly 100 (fn [] (let [start (.getCurrentThreadCpuTime cpu)]
                                                  (dotimes [_ 40] (some :keyframes defs))
                                                  (/ (- (.getCurrentThreadCpuTime cpu) start) 4e7)))))))
(let [[output] *command-line-args*]
  (try (let [report (mapv (fn [n] (let [m (setup n)] (assoc (capture m) :authored-key-lookup-ms (probe-scan m)))) [32 128 256])]
         (spit output (pr-str report)) (prn report))
       (finally (shutdown-agents))))
