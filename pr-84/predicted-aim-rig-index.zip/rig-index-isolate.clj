(require '[clojure.java.io :as io] '[afterglow.runtime.keyframes.values :as values])
(import '[java.lang.management ManagementFactory ThreadMXBean])
(def ^ThreadMXBean cpu-bean (ManagementFactory/getThreadMXBean))
(defn summarize [xs]
  (let [xs (vec (sort xs))]
    {:n (count xs) :median (nth xs (quot (count xs) 2)) :p95 (nth xs (dec (int (* 0.95 (count xs)))))
     :mean (/ (reduce + xs) (count xs)) :max (peek xs)}))
(defn sample [f]
  (let [start (.getCurrentThreadCpuTime cpu-bean)]
    (f)
    (/ (- (.getCurrentThreadCpuTime cpu-bean) start) 1e6)))
(defn pair [pixels heads]
  (let [rig (mapv (fn [i] {:id (str "head-" i) :position [(double (mod i 29)) 6.0 (double (mod i 91))]}) (range (+ pixels heads)))
        ids (mapv :id (subvec rig pixels))
        endpoint (fn [z] [{:kind :batch :batch {:target-ids ids :outputs {:aim {:type :vec3 :components 3
                                      :values (double-array (mapcat (fn [i] [(double (mod i 19)) -0.1 z]) (range heads)))}}}}])
        origin (endpoint -19.0) target (endpoint -19.5)
        index (values/fixture-positions rig)
        check (fn [result] (when-not (and (identical? origin (first result)) (identical? target (second result)))
                              (throw (ex-info "Unexpected endpoint" {}))))
        calls {:scan #(check (values/endpoints origin target rig :linear))
               :reuse #(check (values/indexed-endpoints origin target index :linear))}]
    (doseq [output [origin target]] (values/validate-blocks! output false))
    (doseq [_ (range 100) f (vals calls)] (f))
    {:pixels pixels :heads heads :rounds
     (mapv (fn [mode] [mode (summarize (repeatedly 160 #(sample (calls mode))))]) [:scan :reuse :reuse :scan])}))
(let [report (mapv (fn [pixels] (pair pixels 128)) [1024 8192])]
  (spit (or (first *command-line-args*) "rig-index-isolated.edn") (pr-str report))
  (prn report))
