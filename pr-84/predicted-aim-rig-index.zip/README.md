# Replaying predictive aim validation

The full-show captures use Tolglow b0bd265367590df0e74a54f6e96e0e38f3be61c0 and the two Afterglow revisions in revisions.txt. Use clean checkouts, a JDK with ThreadMXBean CPU accounting enabled, and Leiningen. From the Tolglow checkout, run the following for each Afterglow checkout, in the order baseline, candidate, candidate, baseline. Supply a separate output filename for each run.

```sh
AFTERGLOW_ROOT=/absolute/path/to/afterglow lein with-profile +benchmark run \
  -m tolglow.perf.admission-cost output.edn 1024 128 48 80
```

Each process warms 48 frames and captures 80 in each lane. Compare the two :steer held-out rows in each report. Read [:steer :endpoint :worker-ms] for the complete endpoint worker time. :sample-cpu-ms is the subset charged to the effect evaluator. Each file includes the full-rate output pulse/shutter trace and every run checks native aim, color, every DMX byte, pulse and shutter output, cue lifecycle and intents against full-rate results.

The second experiment runs only the endpoint geometry checks. Run it with the candidate's source and dependencies on the classpath. For example, from the candidate checkout use:

```sh
java -cp "$(lein classpath)" clojure.main rig-index-isolate.clj output-isolate.edn
```

This final argument selects the EDN file. It compares a fresh rig scan with a prepared lookup for every validated endpoint while using the same real endpoint checks in both lanes. It warms 100 pairs, then measures 160 calls in each of four runs. It excludes worker dispatch, effects, presentation and hardware.

An additional full-state comparison used the same Tolglow checkout and rig. It compared complete instance maps and complete effect intent records on every frame in addition to the per-universe and visual checks. Run this command with both Afterglow checkouts, then compare the resulting EDN files byte for byte:

```sh
AFTERGLOW_ROOT=/absolute/path/to/afterglow lein with-profile +benchmark run \
  -m clojure.main /absolute/path/to/rig-index-parity.clj output-parity.edn
```
