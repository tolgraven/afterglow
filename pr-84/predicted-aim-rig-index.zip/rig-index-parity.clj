(require '[tolglow.perf.admission-cost :as admission] '[tolglow.perf.multirate-quality :as quality]
         '[tolglow.bench-show :as bench] '[clojure.java.io :as io])
(import '[java.lang.management ManagementFactory] '[java.security MessageDigest])
(let [[output] *command-line-args*
      pixels 1024 movers 128 warmup 48 frames 80
      {:keys [fixtures]} (bench/corpus pixels movers :sculpture)
      rig (into (subvec fixtures 0 pixels) (map #(assoc-in % [:channels :shutter] 12)) (subvec fixtures pixels))
      inputs {:pixels pixels :fixtures rig :model (#'admission/scene rig pixels)}
      read-output quality/read-frame
      full-state (fn [state fs p]
                   (assoc (read-output state fs p)
                          :intents (get-in state [:status :last-intents])
                          :lifecycle (get-in state [:model :instances])))
      record (fn [rates reference]
               (#'admission/replay (ManagementFactory/getThreadMXBean) inputs rates warmup frames reference))
      digest (MessageDigest/getInstance "SHA-256")]
  (with-redefs [quality/read-frame full-state]
    (let [rows (:frames (record {:wash 1 :steer 1} nil))]
      (record {:wash 1 :steer 2} rows)
      (doseq [row rows [_ packet] (sort-by key (:dmx row))] (.update digest ^bytes packet))
      (spit output (pr-str {:frame-count frames :universe-ids (vec (sort (keys (:dmx (first rows)))))
                            :raw-dmx-sha256 (.formatHex (java.util.HexFormat/of) (.digest digest))
                            :intents (mapv :intents rows)
                            :instances (mapv (fn [r] (into (sorted-map) (map (fn [[id instance]]
                                                                     [id (select-keys instance [:cue-id :effect-id :phase :started-at-ms])]))
                                                           (:lifecycle r))) rows)})))))
(shutdown-agents)
