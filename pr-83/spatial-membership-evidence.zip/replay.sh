#!/usr/bin/env bash
set -eu
: "${TOLGLOW_ROOT:?set to Tolglow checkout}"
: "${AFTERGLOW_ROOT:?set to Afterglow PR head}"
capture=$(cd "$(dirname "$0")" && pwd)
classpath=$(cd "$TOLGLOW_ROOT" && lein with-profile +benchmark,+native-gpu classpath)
export LIBGL_ALWAYS_SOFTWARE=1 MESA_SHADER_CACHE_DISABLE=true LP_NUM_THREADS=2
export VENUE_GPU_MS=60000 VENUE_MOVEMENT=cpu VENUE_WORKER_MS=5000 VENUE_MATERIAL_FILE="$capture/mixed-material.clj"
java -Xmx600m -XX:ActiveProcessorCount=2 -cp "$classpath" clojure.main "$capture/event-cases.clj" "$capture/events.edn"
VENUE_PIXELS=10000 java -Xms1250m -Xmx1250m -XX:ActiveProcessorCount=3 -cp "$classpath" clojure.main "$capture/attributed.clj" "$capture/10k.edn" 14 28
VENUE_PIXELS=20000 java -Xms1400m -Xmx1400m -XX:ActiveProcessorCount=3 -cp "$classpath" clojure.main "$capture/paired.clj" "$capture/20k.edn" 16 32
