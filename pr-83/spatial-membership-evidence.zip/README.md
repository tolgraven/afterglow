# Spatial membership event comparisons

The benchmark uses Tolglow 39defcc0cbc65d216a806a7ca818f6895df3f4aa with Afterglow 252e546cffc2ca1d146093c3cf24b6d06c45e84a. The reference is its immediate parent master 844198c6510e32be28b6b6e51cb07724d4e98a41. The compact bench scripts install the released transitions function from that parent or the candidate implementation while advancing the real show. Both sides use the same renderers and physical packet sink.

The two show instances use the sculpture’s mixed surface UVs, 64 animated moving heads, four moving optical selection volumes and eight washes. Metered frames alternate run order. Both lanes capture every spatial transition call. Each pair checks the complete event maps, physical packets, committed model, effect intents and continuous selected preview fields. The 10k rig adds measurements around each event call using coordinator-thread CPU/allocation counters, including 3,162 events on 28 timed pairs. Complete-show CPU/allocation covers the coordinator and the named GPU/renderer workers. GC pauses are JFR overlaps. Every output stayed in memory. Native compute used llvmpipe on Linux, a 60s diagnostic budget and CPU moving-head calibration.

The original sampled show indicated the dominant allocation stack within transitions was persistent set removal. Across 32 frames, the sampled transitions stack contributed about 448 MB. The first allocation sample on each thread was explicitly excluded because it includes allocations since the thread began. The resulting summarized stacks are archived.

Prepare the two checkout revisions, install Leiningen and a software desktop GL display, then set TOLGLOW_ROOT and AFTERGLOW_ROOT and run:

    bash replay.sh

The isolated cases exercise exact ordered event output for mixed keyword and string IDs, and include both highly overlapping and disjoint sets. The unchanged case invokes the helper directly as a negative control. The ordinary public spatial observer already bypasses transitions when the two memberships compare equal. Quantiles use nearest rank throughout. Shared-host timings exclude tangible fixture playback and should be read with the CPU/allocation and 20k tail observations.
