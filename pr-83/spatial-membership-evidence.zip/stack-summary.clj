(import '[jdk.jfr.consumer RecordingFile] '[java.nio.file Paths])
(require '[clojure.string :as str])
(let [recording (Paths/get (first *command-line-args*) (make-array String 0))
      seen (volatile! #{})
      aggregate (reduce
                 (fn [m event]
                   (let [kind (.getName (.getEventType event))]
                     (if-not (#{"jdk.ExecutionSample" "jdk.ObjectAllocationSample"} kind)
                       m
                       (let [alloc? (= "jdk.ObjectAllocationSample" kind)
                             thread (if alloc? (.getThread event) (.getThread event "sampledThread"))
                             id (some-> thread .getJavaThreadId)
                             first? (and alloc? (not (contains? @seen id)))
                             _ (when alloc? (vswap! seen conj id))
                             weight (if alloc? (.getLong event "weight") 1)
                             funcs (->> (some-> event .getStackTrace .getFrames)
                                        (keep #(some-> % .getMethod .getType .getName))
                                        (filter #(re-find #"^(afterglow|tolglow)\." %))
                                        (map #(str/replace % #"\$fn__\d+.*" "")) distinct)
                             bucket (or (first funcs) :other)
                             spatial (filter #(re-find #"^(afterglow|tolglow)\.spatial" %) funcs)]
                         (if first? m
                           (cond-> (-> m
                                       (update-in [kind :all bucket] (fnil + 0) weight)
                                       (update-in [kind :total] (fnil + 0) weight))
                             (seq spatial) (update-in [kind :optical (vec (take 2 funcs))] (fnil + 0) weight)
                             (seq spatial) (update-in [kind :spatial-total] (fnil + 0) weight))))))) {} (RecordingFile/readAllEvents recording))]
  (spit (second *command-line-args*) (pr-str aggregate))
  (doseq [[k d] aggregate]
    (prn k :total (:total d) :spatial (:spatial-total d))
    (prn :all (take 12 (sort-by (comp - val) (:all d))))
    (prn :spatial (take 15 (sort-by (comp - val) (:optical d))))))
