(require '[afterglow.spatial :as s])
(require '[clojure.set :as set])
(defn previous-transitions [id previous current now]
  (into [] (mapcat (fn [[event-type ids]]
                     (map (fn [fixture-id] {:type event-type :volume-id id :fixture-id fixture-id :time-ms now})
                          (sort-by pr-str ids))))
        [[:spatial/exit (set/difference previous current)]
         [:spatial/enter (set/difference current previous)]]))

(import '[java.lang.management ManagementFactory] '[com.sun.management ThreadMXBean])
(def ^ThreadMXBean counter (ManagementFactory/getThreadMXBean))
(defn run [f left right]
  (let [a (.getCurrentThreadAllocatedBytes counter) cpu (.getCurrentThreadCpuTime counter) t (System/nanoTime)
        result (f :moving-sphere left right 1800.0)]
    [result {:bytes (- (.getCurrentThreadAllocatedBytes counter) a)
             :ms (/ (- (System/nanoTime) t) 1e6) :cpu-ms (/ (- (.getCurrentThreadCpuTime counter) cpu) 1e6)}]))
(let [as-id (fn [i] (case (rem i 4) 0 (keyword "rig" (str i)) 1 (keyword (str "moving-" i)) 2 (str "pixel/" i) (str i)))
      before (into #{} (map as-id) (range 12000))
      controls {:steady-sideways (into #{} (map as-id) (range 64 12064))
                :small-change (conj (disj before (as-id 42)) :another)
                :disjoint (into #{} (map as-id) (range 12000 24000))
                :unchanged before}]
  (spit (first *command-line-args*)
        (pr-str (into {} (for [[id after] controls]
                           (let [n (if (= :disjoint id) 6 32)
                                 pair (fn [i]
                                        (let [order (if (even? i) [0 1] [1 0])
                                              a (into {} (for [l order]
                                                           [l (run ([previous-transitions #'s/transitions] l) before after)]))]
                                          (assert (= (get-in a [0 0]) (get-in a [1 0])))
                                          {:events (count (get-in a [0 0])) :baseline (get-in a [0 1]) :candidate (get-in a [1 1])}))]
                             (dotimes [i (min n 8)] (pair i))
                             [id (mapv pair (range n))]))))))
