#!/usr/bin/env bash
set -euo pipefail
kit=$(cd "$(dirname "$0")" && pwd)
out=${1:?provide an output file}
cache=${BENCH_CACHE:-"$kit/.bench-cache"}
mkdir -p "$cache" "$(dirname "$out")"
cache=$(cd "$cache" && pwd)
if [[ "${BENCH_OFFLINE:-0}" == 1 ]]; then export GIT_ALLOW_PROTOCOL=file; fi
out="$(cd "$(dirname "$out")" && pwd)/$(basename "$out")"
if [[ -e "$out" || -e "$out.jfr" ]]; then echo "Choose a new output path: $out" >&2; exit 2; fi
tol=fef01db4a5804559f90f82147dd94c7c19bdfa16
aft=52db646c290fd8f396e788000230bcd220f9f8bc
native=4769e27c4b803c7a4a9f8ed9cd010ae5ddc0039b
uniform=c83375f354cfcee7add00f3e4445edbfa870b513
weights=902c0e09e002d8fa60de58417f96134d0d57ccca
source_at() {
  local repo=$1 rev=$2 existing=$3 dest="$cache/$1"
  if [[ -n "$existing" ]]; then
    dest=$(cd "$existing" && pwd)
    [[ "$(git -C "$dest" rev-parse HEAD)" == "$rev" ]] || { echo "Expected $repo at $rev" >&2; return 1; }
  else
    if [[ "${BENCH_OFFLINE:-0}" == 1 && ! -d "$dest/.git" ]]; then echo "Offline checkout missing: $dest" >&2; return 1; fi
    if [[ ! -d "$dest/.git" ]]; then
      git init -q "$dest"
      git -C "$dest" remote add origin "https://github.com/tolgraven/$repo.git"
      git -C "$dest" config remote.origin.promisor true
      git -C "$dest" config remote.origin.partialclonefilter blob:none
      git -C "$dest" sparse-checkout init --cone >/dev/null
      git -C "$dest" sparse-checkout set src resources dev bin test test-native >/dev/null
    fi
    if ! git -C "$dest" cat-file -e "$rev^{commit}" 2>/dev/null; then
      [[ "${BENCH_OFFLINE:-0}" != 1 ]] || { echo "Offline checkout lacks $rev" >&2; return 1; }
      git -C "$dest" fetch -q --depth=1 --filter=blob:none origin "$rev"
    fi
    git -C "$dest" checkout -q --detach "$rev"
  fi
  printf '%s\n' "$dest"
}
tol_root=$(source_at tolglow "$tol" "${TOLGLOW_ROOT:-}")
aft_root=$(source_at afterglow "$aft" "${AFTERGLOW_ROOT:-}")
export AFTERGLOW_ROOT="$aft_root"
for rev in "$native" "$uniform" "$weights"; do
  if ! git -C "$aft_root" cat-file -e "$rev^{commit}" 2>/dev/null; then
    if [[ "${BENCH_OFFLINE:-0}" == 1 ]]; then echo "Missing pinned comparison ref $rev in $aft_root" >&2; exit 2; fi
    git -C "$aft_root" fetch -q --depth=1 --filter=blob:none origin "$rev"
  fi
done
overlay="$cache/source-overlays"
mkdir -p "$overlay/afterglow/render/gpu"
for path in compute fields frame gpu/session hdr; do
  git -C "$aft_root" show "$uniform:src/afterglow/render/$path.clj" > "$overlay/afterglow/render/$path.clj"
done
git -C "$aft_root" show "$native:src/afterglow/render/presentation.clj" > "$overlay/afterglow/render/presentation.clj"
git -C "$aft_root" show "$weights:src/afterglow/render/layers.clj" > "$overlay/afterglow/render/layers.clj"
java_bin=${JAVA_HOME:+"${JAVA_HOME}/bin/"}java
java_major() {
  "$1" -XshowSettings:properties -version 2>&1 | awk '/java.specification.version =/ {print $NF; found=1} END {if (!found) print 0}'
}
major=$(java_major "$java_bin" || true)
if [[ ! "$major" =~ ^[0-9]+$ || "$major" -lt 21 ]]; then
  if [[ "$(uname -s)" != Darwin ]]; then echo "Set JAVA_HOME to a JDK 21 or newer" >&2; exit 2; fi
  mac_arch=$(uname -m)
  if [[ "$mac_arch" == arm64 ]]; then
    asset_arch=aarch64
    digest=48067f2b7c958ed104a9d8a5749be7d25220b0a356b4d2d1bcfaab3e16ad0b14
  elif [[ "$mac_arch" == x86_64 ]]; then
    asset_arch=x64
    digest=1b5eff1741bb83d32e2e19aade71452bb42e40f047c01d3e178d438304c9a26d
  else
    echo "Set JAVA_HOME for this architecture" >&2; exit 2
  fi
  java_home_dir="$cache/temurin-21.0.13.1-$asset_arch"
  if [[ ! -x "$java_home_dir/Contents/Home/bin/java" ]]; then
    [[ "${BENCH_OFFLINE:-0}" != 1 ]] || { echo "Offline JDK 21 unavailable" >&2; exit 2; }
    jdk_tmp=$(mktemp -d "$cache/jdk.XXXXXXXX")
    curl --fail --location --retry 3 "https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.13.1%2B2/OpenJDK21U-jdk_${asset_arch}_mac_hotspot_21.0.13.1_2.tar.gz" -o "$jdk_tmp/archive.tar.gz"
    printf '%s  %s
' "$digest" "$jdk_tmp/archive.tar.gz" | shasum -a 256 -c - >&2
    mkdir "$jdk_tmp/unpacked"
    tar -xzf "$jdk_tmp/archive.tar.gz" --strip-components 1 -C "$jdk_tmp/unpacked"
    test -x "$jdk_tmp/unpacked/Contents/Home/bin/java"
    mv "$jdk_tmp/unpacked" "$java_home_dir"
    rm "$jdk_tmp/archive.tar.gz"
    rmdir "$jdk_tmp"
  fi
  export JAVA_HOME="$java_home_dir/Contents/Home"
  java_bin="$JAVA_HOME/bin/java"
fi
if [[ -n "${JAVA_HOME:-}" ]]; then export PATH="$JAVA_HOME/bin:$PATH"; fi
if command -v lein >/dev/null 2>&1; then
  lein_cmd=(lein)
else
  jar="$cache/leiningen-2.13.1-standalone.jar"
  if [[ ! -f "$jar" ]]; then
    [[ "${BENCH_OFFLINE:-0}" != 1 ]] || { echo "Offline Leiningen installation missing" >&2; exit 2; }
    curl --fail --location --retry 3 https://github.com/technomancy/leiningen/releases/download/2.13.1/leiningen-2.13.1-standalone.jar -o "$jar.part"
    printf '%s  %s\n' 2e4c36cbaef717d0fa589a1f95e4c526a1cb6c35b48dc92e6dbb30d6f8595b5c "$jar.part" | shasum -a 256 -c - >&2
    mv "$jar.part" "$jar"
  fi
  lein_cmd=("$java_bin" -cp "$jar" clojure.main -m leiningen.core.main)
fi
if [[ "${BENCH_OFFLINE:-0}" == 1 ]]; then lein_cmd+=(-o); fi
entries=$(cd "$tol_root" && "${lein_cmd[@]}" with-profile +benchmark,+native-gpu classpath)
export BENCH_MODE=gpu-show BENCH_PLATFORM="$kit/platform.clj"
export CANDIDATE_CHAIN="$kit/chain.clj" VENUE_MATERIAL_FILE="$kit/beat-material.clj"
export VENUE_PIXELS=${BENCH_PIXELS:-20000} VENUE_WORKER_MS=8000 VENUE_MOVEMENT=cpu
if [[ "$(uname -s)" == Darwin ]]; then
  BENCH_CHIP=$(sysctl -n machdep.cpu.brand_string 2>/dev/null || true)
  BENCH_MODEL=$(sysctl -n hw.model 2>/dev/null || true)
else
  BENCH_CHIP=$(uname -m)
  BENCH_MODEL=
fi
export BENCH_CHIP BENCH_MODEL
warmup=${BENCH_WARMUP:-18}
samples=${BENCH_SAMPLES:-36}
for n in "$VENUE_PIXELS" "$warmup" "$samples"; do [[ "$n" =~ ^[1-9][0-9]*$ ]] || { echo "Counts must be positive integers" >&2; exit 2; }; done
export VENUE_GPU_MS=60000
printf 'Running the paired shader show on %s pixels after %s warmups. Results in %s\n' "$VENUE_PIXELS" "$warmup" "$out" >&2
exec "$java_bin" -XX:ActiveProcessorCount="${BENCH_PROCESSORS:-2}" -Xms640m -Xmx"${BENCH_HEAP:-1200m}" -cp "$overlay:$aft_root/src:$entries" clojure.main "$kit/paired.clj" "$out" "$warmup" "$samples"
