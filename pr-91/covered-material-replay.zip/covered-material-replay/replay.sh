#!/usr/bin/env bash
set -euo pipefail
kit=$(cd "$(dirname "$0")" && pwd)
result=${1:?provide a new output directory}
mkdir -p "$result"
result=$(cd "$result" && pwd)
for size in 10000 20000; do
  BENCH_PIXELS=$size BENCH_WARMUP=${BENCH_WARMUP:-18} BENCH_SAMPLES=${BENCH_SAMPLES:-36} VENUE_WASHES=8 "$kit/launch.sh" "$result/covered-$size.edn"
done
BENCH_PIXELS=10000 BENCH_WARMUP=${BENCH_WARMUP:-12} BENCH_SAMPLES=${BENCH_SAMPLES:-24} VENUE_WASHES=0 "$kit/launch.sh" "$result/no-cover.edn"
python3 "$kit/read-rows.py" "$result/covered-10000.edn" "$result/covered-20000.edn" "$result/no-cover.edn"
