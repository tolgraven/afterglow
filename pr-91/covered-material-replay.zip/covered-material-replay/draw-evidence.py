"""Render the recorded diagnostic and measured elapsed frames."""
import io
import re
import runpy
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image

base = Path(__file__).resolve().parent
table = runpy.run_path(str(base / 'read-rows.py'))
scenarios = [('10,000 pixels', 'crossed-10k.edn'),
             ('20,000 pixels', 'crossed-20k.edn'),
             ('10,000 · wash removed', 'crossed-no-wash-10k.edn')]
runs = [table['rows'](base / file) for _, file in scenarios]
traffic = [[int(b) / 1000 for b in re.findall(r':readback-bytes (\d+)', (base / file).read_text())]
           for _, file in scenarios]
colors = ['#855626', '#00715f']
bg = '#fafaf5'
samples = len(runs[0]) // 2
total = sum(len(r) for r in runs)
reached = sum(row['ms'] <= 25 for run in runs for row in run)

def draw(frame):
    fig = plt.figure(figsize=(11.2, 6.0), dpi=115, facecolor=bg)
    grid = fig.add_gridspec(2, 2, width_ratios=[0.9, 1.4], hspace=0.26, wspace=0.24,
                            left=.09, right=.975, top=.77, bottom=.15)
    fig.text(.04, .923, 'Skipping a shader covered by a wash', fontsize=21, fontweight='bold', color='#163b32')
    fig.text(.041, .862, '64 moving heads · four moving spheres · software OpenGL · in-memory ArtDMX',
             color='#33564c', fontsize=11)
    fig.text(.04, .805, '━ Original planner', color=colors[0], fontsize=10)
    fig.text(.20, .805, '━ Coverage-aware planner', color=colors[1], fontsize=10)
    ax = fig.add_subplot(grid[:, 0])
    y = [2, 1, 0]
    for j, (name, bars) in enumerate(zip(scenarios, traffic)):
        for lane, value in enumerate(bars):
            pos = y[j] + (.13 if lane == 0 else -.13)
            ax.barh(pos, value, .17, color=colors[lane])
            ax.text(value + 5, pos, f'{value:.0f}', va='center', fontsize=9, color=colors[lane])
        ax.text(4, y[j] + .30, name[0], fontsize=9, color='#26463c')
    ax.set_title('GPU readback per diagnostic frame', fontsize=11, loc='left', fontweight='bold')
    ax.set_xlim(0, 465); ax.set_ylim(-.4, 2.58); ax.set_yticks([]); ax.set_xlabel('kB (1,000 bytes)', fontsize=9)
    axes = [ax]
    for j, run in enumerate(runs[:2]):
        ax = fig.add_subplot(grid[j, 1]); axes.append(ax)
        for lane in [0, 1]:
            ys = [r['ms'] for r in run if r['lane'] == lane]
            ax.plot(range(1, frame + 1), ys[:frame], lw=1.05, color=colors[lane])
            ax.scatter(frame, ys[frame-1], color=colors[lane], s=9)
        ax.axhline(25, lw=.8, linestyle='dashed', color='#4f5c55')
        ax.set_xlim(1, samples); ax.set_ylim(0, max(r['ms'] for r in run) * 1.07)
        ax.set_ylabel('Frame (ms)', fontsize=8)
        ax.set_title(f'{scenarios[j][0]} · measured whole frames', loc='left', fontsize=10, fontweight='bold')
        if j: ax.set_xlabel('Frame pair', fontsize=9)
    for ax in axes:
        ax.set_facecolor(bg)
        for edge in ['top', 'right']: ax.spines[edge].set_visible(False)
        for edge in ['bottom', 'left']: ax.spines[edge].set_color('#c0ccbf')
        ax.tick_params(labelsize=8); ax.grid(axis='x' if ax is axes[0] else 'y', color='#d9e4d7', lw=.5)
    fig.text(.041, .045, f'{reached}/{total} whole frames met 25 ms. Output packets and ordered fixture contact events matched on every pair.',
             color='#33564c', fontsize=10)
    image = io.BytesIO()
    fig.savefig(image, format='png', facecolor=bg)
    plt.close(fig); image.seek(0)
    return Image.open(image).convert('RGB')

if __name__ == '__main__':
    prefix = Path(sys.argv[1])
    draw(samples).save(prefix.with_suffix('.png'), optimize=True)
    frames = [draw(i) for i in sorted({1, *range(4, samples+1, 4), samples})]
    frames[0].save(prefix.with_suffix('.gif'), save_all=True, append_images=frames[1:], loop=0,
                   duration=[350]*(len(frames)-1)+[1500], optimize=True)
