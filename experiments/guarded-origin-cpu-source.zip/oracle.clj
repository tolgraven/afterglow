(require '[afterglow.spatial.field :as field])
(load-file (System/getenv "SPHERE_SAMPLER"))
(require '[lighting-benchmark.sphere-shortcut :as cutoff])
(def candidate (cutoff/wrap @#'field/point-sampler))
(defn bits [^double n] (Double/doubleToLongBits n))
(defn same-samples! [shape points]
  (let [baseline (:weight-at (field/prepare shape))
        optimized (:weight-at (with-redefs-fn {#'field/point-sampler candidate} #(field/prepare shape)))]
    (doseq [p points]
      (let [a (bits (double (baseline p))) b (bits (double (optimized p)))]
        (assert (= a b) [shape p a b])))))
(defn near [v]
  (let [v (double v) width (Math/ulp v)]
    (map #(+ v (* width %)) [-256 -128 -65 -64 -63 -32 -8 -2 -1 0 1 2 8 32 63 64 65 128 256])))
(def dirs [[1.0 0.0 0.0] [-1.0 0.0 0.0] [0.0 0.6 0.8]
           [0.5773502691896258 0.5773502691896258 0.5773502691896258]])
(defn datasets [r]
  (for [core [0.0 (* r 0.25) (Math/nextDown (double r)) r (Math/nextUp (double r)) (* r 1.5)]
        spill [0.0 (* r 0.01) (* r 0.5)]
        curve [:linear :smoothstep]]
    [core spill curve]))
(let [start (System/nanoTime)
      done (volatile! 0)]
  (doseq [r [1e-70 1e-60 1e-30 1e-10 0.1 3.0 1e15 1e60 1e70]
          [inner outer curve] (datasets r)
          pos [[0.0 0.0 0.0] [0.137 -0.331 0.217] [1e15 -2e15 1e15]]]
    (let [vol {:shape :sphere :radius r :position pos :strength 0.6875
               :falloff {:inner-m inner :outer-m outer :curve curve}}
          points (for [boundary [0.0 (- r inner) r (+ r outer) (* 1.03 r) (* 10.0 r)]
                       d (near boundary) axis dirs]
                   (mapv #(+ %1 (* d %2)) pos axis))]
      (same-samples! vol points)
      (vswap! done + (count points))))
  (println :exact-double-checks @done :elapsed-ms (/ (- (System/nanoTime) start) 1e6)))
