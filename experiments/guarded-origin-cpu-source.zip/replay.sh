#!/usr/bin/env bash
set -euo pipefail
: "${TOLGLOW_ROOT:?Set TOLGLOW_ROOT to your local Tolglow clone}"
: "${AFTERGLOW_ROOT:?Set AFTERGLOW_ROOT to your local Afterglow clone}"
kit=$(cd "$(dirname "$0")" && pwd)
mkdir -p "${1:-./results}"
results=$(mktemp -d "${1:-./results}/cpu-sphere.XXXXXXXX")
results=$(cd "$results" && pwd)
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
mkdir -p "$work/t" "$work/a" "$work/overlay/afterglow/render/gpu"
git -C "$TOLGLOW_ROOT" archive fef01db4 | tar -x -C "$work/t"
git -C "$AFTERGLOW_ROOT" archive 52db646c | tar -x -C "$work/a"
for path in compute fields frame gpu/session hdr; do
  git -C "$AFTERGLOW_ROOT" show "c83375f:src/afterglow/render/$path.clj" >"$work/overlay/afterglow/render/$path.clj"
done
git -C "$AFTERGLOW_ROOT" show 4769e27:src/afterglow/render/presentation.clj >"$work/overlay/afterglow/render/presentation.clj"
git -C "$AFTERGLOW_ROOT" show 902c0e0:src/afterglow/render/layers.clj >"$work/overlay/afterglow/render/layers.clj"
cp_entries=$(cd "$work/t" && AFTERGLOW_ROOT="$work/a" lein with-profile +benchmark,+native-gpu classpath)
export BENCH_MODE=cpu-show VENUE_MOVEMENT=cpu VENUE_WORKER_MS=20000 VENUE_WASHES=8
unset VENUE_GPU_MS
export SPHERE_SAMPLER="$kit/point.clj" BENCH_PLATFORM="$kit/platform.clj" VENUE_MATERIAL_FILE="$kit/beat-material.clj"
cmd=(java -Djava.awt.headless=true -XX:ActiveProcessorCount=2 -Xms640m -Xmx1200m -cp "$work/overlay:$work/a/src:$cp_entries" clojure.main)
"${cmd[@]}" "$kit/oracle.clj" > "$results/exact.log"
failure=0
for size in 10000 20000; do
  if ! VENUE_PIXELS="$size" "${cmd[@]}" "$kit/host.clj" "$results/$size.edn" "${BENCH_WARMUP:-18}" "${BENCH_SAMPLES:-36}" >"$results/$size.log" 2>&1; then
    echo "$size pixel replay failed. See $results/$size.log." >&2
    failure=1
  fi
done
printf 'Results: %s\n' "$results"
exit "$failure"
