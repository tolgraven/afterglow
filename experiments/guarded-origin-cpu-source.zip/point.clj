(ns lighting-benchmark.sphere-shortcut
  (:import [clojure.lang IFn$DD]))

(defn- squared ^double [^double x] (* x x))

(defn- fixed-bands [radius inner outer]
  (let [r (double radius)
        half-width (max (double inner) (double outer))
        magnitude (max r half-width)]
    ;; Both distance boundaries and their squares stay in the normal range.
    (when (and (<= 1e-60 magnitude) (<= magnitude 1e60))
      (let [guard (* 64.0 (Math/ulp magnitude))
            core (- r (double inner) guard)
            limit (+ r (double outer) guard)]
        [(if (pos? core) (squared core) -1.0) (squared limit)]))))

(defn- point-weight [[cx cy cz] radius strength ^IFn$DD response [core-squared limit-squared]]
  (let [cx (double cx) cy (double cy) cz (double cz)
        r (double radius) strength (double strength)
        core (double core-squared) limit (double limit-squared)]
    (fn [[x y z]]
      (let [dx (- (double x) cx) dy (- (double y) cy) dz (- (double z) cz)
            q (+ (* dx dx) (* dy dy) (* dz dz))]
        (cond
          (< q core) strength
          (> q limit) 0.0
          :else (.invokePrim response (- (Math/hypot (Math/hypot dx dy) dz) r)))))))

(defn wrap [original]
  (fn [{:keys [translation scale position falloff] :as volume} shape response radius width strength]
    (or (when (and (instance? IFn$DD response) (nil? translation) (nil? scale) (every? double? position))
          (let [{:keys [inner-m outer-m] :or {inner-m 0.0 outer-m 0.0}} falloff]
            (when-let [bands (fixed-bands radius inner-m outer-m)]
              (point-weight position radius strength response bands))))
        (original volume shape response radius width strength))))
