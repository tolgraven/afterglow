(ns lighting-benchmark.sphere-classification
  (:require [afterglow.spatial.field :as field]
            [afterglow.spatial.geometry :as geometry]
            [afterglow.render.gpu.expressions :as gpu]
            [tolglow.perf.weighted-venue :as venue])
  (:import [java.lang.management ManagementFactory]
           [com.sun.management ThreadMXBean]))

(defn op [k & xs] {:op k :args (vec xs)})
(defn lit [v] {:op :const :value v})
(defn slot [i k] (keyword (str "s" i (name k))))
(defn param [i k] {:op :param :key (slot i k)})
(def axes [:x :y :z])
(defn le [x] (op :floor (op :clamp (op :add (lit 1) x) (lit 0) (lit 1))))
(defn sphere-code [i]
  (let [squares (map (fn [k] (let [d (op :subtract {:op :position :axis k} (param i k))]
                               (op :multiply d d))) axes)
        distance (apply op :add squares)
        full (le (op :subtract (param i :core) distance))
        empty (le (op :subtract distance (param i :empty)))]
    (op :multiply (lit (bit-shift-left 1 (* 2 i))) (op :add full (op :multiply (lit 2) empty)))))
(def shader {:classification (apply op :add (map sphere-code (range 4)))})
(defn uniforms [volumes]
  ;; Scoped to this measured +/-32 m room. Error budget exceeds 128 float32
  ;; epsilons times the square of the largest absolute coordinate.
  (let [margin 0.02]
    {:params
     (reduce-kv (fn [acc i {:keys [position radius falloff]}]
                  (let [inner (- radius (:inner-m falloff)) outer (+ radius (:outer-m falloff))]
                    (assert (and (< inner 32.0) (pos? inner) (every? #(< (abs %) 32.0) position)))
                    (-> (into acc (map (fn [k x] [(slot i k) x]) axes position))
                        (assoc (slot i :core) (- (* inner inner) margin)
                               (slot i :empty) (+ (* outer outer) margin)))))
                {} volumes)}))
(defn classes! [owner volumes]
  (get-in (gpu/evaluate! owner (uniforms volumes)) [:outputs :classification :values]))

(defn replay-position [rows {:keys [weight-at max-weight]} ^doubles classification channel]
  (let [shift (long (* channel 2)), n (count rows)]
    (loop [i 0, result (transient {})]
      (if (< i n)
        (let [code (bit-and 3 (unsigned-bit-shift-right (long (aget classification i)) shift))]
          (if (= code 2)
            (recur (inc i) result)
            (let [[id point] (nth rows i)
                  weight (case code 0 (weight-at point) 1 max-weight
                               (throw (ex-info "unexpected classifier code" {:row i :code code})))]
              (recur (inc i) (if (pos? weight) (assoc! result id weight) result)))))
        (persistent! result)))))

(def ^ThreadMXBean mx (ManagementFactory/getThreadMXBean))
(defn measure [f]
  (let [cpu (.getCurrentThreadCpuTime mx) alloc (.getCurrentThreadAllocatedBytes mx) t (System/nanoTime)
        result (f)]
    {:ms (/ (- (System/nanoTime) t) 1e6) :cpu (/ (- (.getCurrentThreadCpuTime mx) cpu) 1e6)
     :bytes (- (.getCurrentThreadAllocatedBytes mx) alloc) :value result}))
(defn stats [xs] (let [sorted (vec (sort xs)) n (count xs)] (mapv #(nth sorted (dec (int (Math/ceil (* % n))))) [0.5 0.95])))
(defn compare-frame [rig owner i]
  (let [vs (venue/volumes 4 #{:position} (* i 0.05)) rs (:rows rig)
        samples (mapv field/prepare vs)
        ref #(measure (fn [] (mapv (fn [s] (#'field/position-weights s rig)) samples)))
        calc #(let [c (measure (fn [] (classes! owner vs)))
                    out (measure (fn [] (mapv (fn [j] (replay-position rs (samples j) (:value c) j)) (range 4))))]
                {:gpu (dissoc c :value) :repair (dissoc out :value) :value (:value out) :codes (:value c)})
        [a b] (if (even? i) [(ref) (calc)] (let [b (calc)] [(ref) b]))
        result (mapv = (:value a) (:value b))
        ^doubles codes (:codes b)]
    (assert (every? true? result) {:i i :results result})
    {:ref (dissoc a :value) :gpu (:gpu b) :repair (:repair b)
     :uncertain
     (loop [row 0 uncertain 0]
       (if (== row (alength codes)) uncertain
         (let [c (long (aget codes row))
               n (reduce (fn [n j] (if (zero? (bit-and 3 (unsigned-bit-shift-right c j))) (inc n) n))
                         0 [0 2 4 6])]
           (recur (inc row) (long (+ uncertain n))))))}))
(defn compare-origin! [size output]
  (let [fixtures (get-in (#'venue/venue size) [:model :rig :fixtures])
        rig (geometry/prepare-rig fixtures)
        rows (:rows rig), world (mapv second rows)
        _ (assert (every? #(every? (fn [x] (< (abs x) 32)) %) world))]
    (with-open [owner (gpu/open! shader world {:timeout-ms 10000})]
      (lighting-benchmark.platform/check-renderer! (lighting-benchmark.platform/renderer (:resources owner)))
      (dotimes [i 18] (compare-frame rig owner i))
      (let [rows (mapv #(compare-frame rig owner %) (range 18 54))
            both (fn [row k] (+ (get-in row [:gpu k]) (get-in row [:repair k])))
            summary {:size size :heads (count world) :readback-bytes (* 4 (count world))
                     :graphics (lighting-benchmark.platform/renderer (:resources owner))
                     :positions-uploaded-once (* 12 (count world)) :frames (count rows)
                     :uncertain (stats (map :uncertain rows))
                     :ref (stats (map #(get-in % [:ref :ms]) rows)) :gpu (stats (map #(get-in % [:gpu :ms]) rows))
                     :repair (stats (map #(get-in % [:repair :ms]) rows))
                     :gpu-plus-repair (stats (map #(both % :ms) rows))
                     :ref-bytes (stats (map #(get-in % [:ref :bytes]) rows))
                     :gpu-plus-repair-bytes (stats (map #(both % :bytes) rows))}
            detail {:rows rows :summary summary}]
        (prn summary) (spit output (pr-str detail))))))
