(ns lighting-benchmark.sphere-cpu-comparison
  (:require [afterglow.render.gpu.expressions :as gpu]
            [afterglow.spatial.field :as field]
            [afterglow.spatial.geometry :as geometry]
            [lighting-benchmark.platform :as platform]
            [lighting-benchmark.sphere-classification :as classifier]
            [tolglow.perf.weighted-venue :as venue]))

(defn- squared-classifier [{[cx cy cz] :position :keys [radius falloff]} {:keys [weight-at max-weight]}]
  (let [cx (double cx) cy (double cy) cz (double cz)
        inner (- (double radius) (double (:inner-m falloff)))
        outer (+ (double radius) (double (:outer-m falloff)))
        full-q (- (* inner inner) 0.02) empty-q (+ (* outer outer) 0.02)]
    (fn [[x y z :as point]]
      (let [dx (- (double x) cx) dy (- (double y) cy) dz (- (double z) cz)
            squared-distance (+ (* dx dx) (* dy dy) (* dz dz))]
        (cond
          (<= squared-distance full-q) max-weight
          (>= squared-distance empty-q) 0.0
          :else (weight-at point))))))

(defn- compare-implementations [rig program frame-index]
  (let [volumes (venue/volumes 4 #{:position} (* frame-index 0.05))
        samples (mapv field/prepare volumes)
        cpu #(mapv (fn [sample] (#'field/position-weights sample rig)) samples)
        bounded (fn [volume sample]
                  (let [quick (squared-classifier volume sample)]
                    (#'field/position-weights (assoc sample :weight-at quick) rig)))
        native (fn []
                 (let [classes (classifier/classes! program volumes)]
                   (mapv #(classifier/replay-position (:rows rig) (samples %) classes %) (range 4))))
        implementations [cpu #(mapv bounded volumes samples) native]
        order (map #(mod (+ frame-index %) 3) (range 3))
        results (into {} (map (fn [lane] [lane (classifier/measure (implementations lane))])) order)]
    (assert (apply = (map :value (vals results))))
    (update-vals results #(dissoc % :value))))

(defn- lane-summary [rows lane]
  (into {} (for [k [:ms :cpu :bytes]]
             [k (classifier/stats (map #(get-in % [lane k]) rows))])))

(defn three-way! [size output]
  (let [fixtures (get-in (#'venue/venue size) [:model :rig :fixtures])
        rig (geometry/prepare-rig fixtures)]
    (with-open [program (gpu/open! classifier/shader (mapv second (:rows rig)) {:timeout-ms 10000})]
      (let [graphics (platform/renderer (:resources program))
            compare-frame! (partial compare-implementations rig program)]
        (platform/check-renderer! graphics)
        (dotimes [i 24] (compare-frame! i))
        (let [rows (mapv compare-frame! (range 24 72))
              summary (into {} (map (fn [lane] [lane (lane-summary rows lane)])) [0 1 2])
              report {:size size :graphics graphics :frames (count rows) :summary summary}]
          (prn report)
          (spit output (pr-str (assoc report :rows rows))))))))
