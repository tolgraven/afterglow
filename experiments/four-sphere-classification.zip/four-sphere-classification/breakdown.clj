(load-file (System/getenv "BENCH_PLATFORM"))
(load-file (str (System/getenv "CLASSIFIER_DIR") "/pruning.clj"))
(lighting-benchmark.platform/run-cli!
 #(lighting-benchmark.sphere-classification/compare-origin! (parse-long (System/getenv "VENUE_PIXELS"))
                                                            (first *command-line-args*)))
