#!/usr/bin/env bash
set -euo pipefail
kit=$(cd "$(dirname "$0")" && pwd)
root=${1:?provide a results parent directory}
mkdir -p "$root"
result=$(mktemp -d "$root/sphere-classification.XXXXXXXX")
result=$(cd "$result" && pwd)
failed=0
run() {
  local name=$1 mode=$2 pixels=$3
  if BENCH_PIXELS="$pixels" "$kit/launch.sh" "$mode" "$result/$name.edn" > "$result/$name.log" 2>&1; then
    printf '%s passed\n' "$name" | tee -a "$result/status.txt"
  else
    failed=1
    printf '%s failed\n' "$name" | tee -a "$result/status.txt"
    tail -n 8 "$result/$name.log" >&2
  fi
}
run boundaries bounds 1000
for size in 10000 20000; do
  run "kernel-$size" kernel "$size"
  run "host-$size" host "$size"
done
printf 'Results are in %s\n' "$result"
exit "$failed"
