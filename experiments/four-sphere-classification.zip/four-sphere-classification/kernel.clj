(load-file (System/getenv "BENCH_PLATFORM"))
(load-file (str (System/getenv "CLASSIFIER_DIR") "/pruning.clj"))
(load-file (str (System/getenv "CLASSIFIER_DIR") "/cpu.clj"))
(lighting-benchmark.platform/run-cli!
 #(lighting-benchmark.sphere-cpu-comparison/three-way! (parse-long (System/getenv "VENUE_PIXELS"))
                                                       (first *command-line-args*)))
