(load-file (System/getenv "BENCH_PLATFORM"))
(load-file (str (System/getenv "CLASSIFIER_DIR") "/pruning.clj"))
(require '[lighting-benchmark.sphere-classification :as c] '[afterglow.spatial.field :as f] '[afterglow.render.gpu.expressions :as gpu])
(defn test-boundaries [i]
  (let [random (java.util.Random. (long (+ 3611 i)))
        volumes (mapv (fn [k] {:shape :sphere :position [(+ (* 0.01 i) (- (* 10.01 k) 15.03)) 0.75 1.3]
                              :radius (+ 1.5 (* k 0.413)) :falloff {:inner-m 0.5 :outer-m 1.0 :curve :smoothstep}
                              :selection #{:position} :strength 0.8}) (range 4))
        positions (vec (for [v volumes boundary [(- (:radius v) 0.5) (+ (:radius v) 1.0)]
                             delta [-0.1 -0.005 -1.0e-4 -1.0e-6 -1.0e-12 -1.0e-15 0.0 1.0e-15 1.0e-12 1.0e-6 1.0e-4 0.005 0.1]
                             _ (range 6)
                             :let [xyz (repeatedly 3 #(- (.nextDouble random) 0.5))
                                   norm (Math/sqrt (reduce + (map #(* % %) xyz)))
                                   d (+ boundary delta)]]
                         (mapv (fn [x c] (+ c (* d (/ x norm)))) xyz (:position v))))
        samples (mapv f/prepare volumes)]
    (with-open [program (gpu/open! c/shader positions {:timeout-ms 10000})]
      (let [_ (lighting-benchmark.platform/check-renderer! (lighting-benchmark.platform/renderer (:resources program)))
            ^doubles values (c/classes! program volumes)]
        (frequencies (for [i (range (alength values)) j (range 4)
                           :let [bits (long (aget values i))
                                 code (bit-and 3 (unsigned-bit-shift-right bits (* j 2)))
                                 w ((:weight-at (samples j)) (positions i))]]
                       (do (assert (case code 0 true 1 (== w 0.8) 2 (zero? w) false) [i j code w])
                           code)))))))
(lighting-benchmark.platform/run-cli!
 #(let [counts (apply merge-with + (map test-boundaries (range 8)))]
    (spit (first *command-line-args*) (pr-str counts))
    (prn counts)))
