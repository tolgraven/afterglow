Neither full show met the 25 ms deadline in 36 measured frame pairs at either size. A single extra shader draw per frame classified all four spherical queries at every fixture origin and left the feather values to the CPU. At 20,000 pixels this transferred another 80,256 bytes. The two complete shows produced identical output, including 158 universes with SHA-256 `41bf4626e8de1f4f84545a4a0788e7755ff59d509f80f5e8c039a64bcc7d2e83`.

| Full show on Mesa software GL | Median whole frame, CPU → GPU origins | Whole frame p95 | Median allocation | Diagnostic readback including all lighting materials |
| --- | ---: | ---: | ---: | ---: |
| 10,000 pixels + 64 heads | 110.47 → 91.16 ms | 565.65 → 310.33 ms | 23.79 → 23.27 MB | 200,336 → 240,592 bytes |
| 20,000 pixels + 64 heads | 217.94 → 198.49 ms | 479.06 → 466.96 ms | 41.24 → 40.13 MB | 400,336 → 480,592 bytes |

| Four origin queries only, 48 rotating measurements per algorithm | Existing indexed CPU, median / p95 | Indexed CPU squared-distance shortcut | GPU classification and exact CPU repair |
| --- | ---: | ---: | ---: |
| 10,000 pixels + 64 heads | 2.95 / 6.48 ms | 2.79 / 5.26 ms | 2.54 / 4.75 ms |
| 20,000 pixels + 64 heads | 10.15 / 16.44 ms | 8.41 / 15.57 ms | 6.85 / 11.30 ms |

At 20,000 pixels, median per-frame coordinator allocation for those four position queries was respectively 1.559 MB, 1.139 MB and 1.322 MB. In an independent 36-frame breakdown, GPU draw, fence and readback took 1.81 ms median and classification decoding, weight-map building and exact repair took 7.81 ms. These separate medians do not sum to an end-to-end percentile. A median 11,148 of 80,256 fixture/volume pairs needed the original double calculation. The 19,968 deliberately near-boundary checks yielded 240 definite core, 15,360 definite outside and 4,368 exact repairs. All classified endpoints and full fixture weight maps matched the CPU reference. The physical lighting deadline and portability to additional room sizes and GPUs remain open.
