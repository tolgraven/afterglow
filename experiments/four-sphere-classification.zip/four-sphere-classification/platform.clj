(ns lighting-benchmark.platform
  (:require [clojure.string :as str]))

(defn system []
  {:os (System/getProperty "os.name")
   :os-version (System/getProperty "os.version")
   :architecture (System/getProperty "os.arch")
   :chip (System/getenv "BENCH_CHIP")
   :model (System/getenv "BENCH_MODEL")
   :java (System/getProperty "java.runtime.version")
   :processors (.availableProcessors (Runtime/getRuntime))
   :tolglow "fef01db4a5804559f90f82147dd94c7c19bdfa16"
   :afterglow "ba73a2b84514b51f8b9d19fd29367e92c6457115"
   :companion-patches ["4769e27" "c83375f" "902c0e0"]})

(defn renderer [metadata]
  (let [name (:renderer metadata)
        software? (boolean (and name (re-find #"(?i)software|llvmpipe|softpipe|swrast|swiftshader|gdi generic|basic render" name)))]
    (assoc (select-keys metadata [:renderer :version]) :kind
           (cond (str/blank? name) :unknown software? :software
                 (re-find #"(?i)apple|intel|amd|radeon|nvidia|adreno|mali|geforce" name) :hardware
                 :else :unknown))))

(defn check-renderer! [report]
  (when-not (or (= :hardware (:kind report))
                (and (= :software (:kind report)) (= "1" (System/getenv "BENCH_ALLOW_SOFTWARE"))))
    (throw (ex-info "Hardware OpenGL renderer required" {:renderer report})))
  report)

(defn distribution [values]
  (let [values (vec (sort values))
        pick (fn [fraction] (get values (dec (long (Math/ceil (* (count values) fraction))))))]
    {:samples (count values) :median (pick 0.5) :p95 (pick 0.95) :max (peek values)}))

(defn run-cli!
  "End the standalone process after the workload has released its resources.
  macOS AWT can keep non-daemon threads alive after the GL drawable is closed."
  [workload]
  (let [status (try
                 (try (workload) (finally (shutdown-agents)))
                 0
                 (catch Throwable failure
                   (.printStackTrace failure System/err)
                   1))]
    (System/exit status)))
