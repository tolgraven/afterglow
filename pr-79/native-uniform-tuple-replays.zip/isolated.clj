(require '[afterglow.render.gpu.session :as session]
         '[afterglow.render.gpu.expressions :as gpu]
         '[afterglow.runtime.reuse :as reuse])
(import '[java.util Arrays])
(defn previous-evaluator [owner stats program]
  (reuse/evaluator {:pure? true :inputs [[:uniforms]]}
    (fn [{:keys [uniforms]}]
      (let [result (gpu/run-program! owner program uniforms)]
        (when (pos? (:count program)) (swap! stats update :draws inc))
        result))))
(defn read-frame [owner group inputs]
  (let [t (System/nanoTime) batch (session/evaluate! owner group inputs)]
    [(/ (- (System/nanoTime) t) 1e6) batch]))
(defn verify! [a b]
  (assert (= (:count a) (:count b)))
  (doseq [[k {:keys [values]}] (:outputs a)]
    (assert (Arrays/equals ^doubles values ^doubles (get-in b [:outputs k :values])))))
(defn measure [fields value-at]
  (with-open [full (session/open!) optimized (session/open!)]
    (let [group (session/group fields (double-array 60000))
          run (fn [i]
                (let [v (value-at i) env {:params {:w [0.5 1.0 v] :x v}}
                      reference #(with-redefs-fn {#'session/program-evaluator previous-evaluator}
                                   (fn [] (read-frame full group env)))
                      candidate #(read-frame optimized group env)
                      times (if (even? i) [(reference) (candidate)] (let [y (candidate)] [(reference) y]))]
                  (verify! (second (first times)) (second (second times)))
                  (mapv first times)))
          status #(mapv (comp :draws session/status) [full optimized])]
      (dotimes [i 24] (run i))
      (let [warm (status) rows (mapv run (range 24 72))]
        {:before warm :after (status) :rows rows}))))
(let [fields {:color {:op :param :type :vec3 :key :w} :focus {:op :param :key :x}}
      f #(double (/ (mod % 16) 16.0))]
  (spit (first *command-line-args*)
        (pr-str {:warmup 24 :samples 48 :heads 20000
                 :held (measure fields #(f (quot % 8)))
                 :changing (measure fields f)
                 :spatial (measure (assoc fields :height {:op :position :axis :z}) #(f (quot % 8)))})))
