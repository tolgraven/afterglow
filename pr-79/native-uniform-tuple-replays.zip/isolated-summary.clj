(defn percentile [xs p]
  (let [n (count xs) index (dec (int (Math/ceil (* p n))))]
    (nth (sort xs) index)))
(let [result (read-string (slurp (first *command-line-args*)))]
  (doseq [k [:held :changing :spatial]]
    (let [sample (k result)]
      (prn k (mapv - (:after sample) (:before sample))
           (mapv (fn [i] (let [times (map #(nth % i) (:rows sample))]
                           [(percentile times 0.5) (percentile times 0.95)])) [0 1])))))
