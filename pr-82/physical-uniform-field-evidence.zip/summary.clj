(defn perc [p xs] (nth (sort xs) (dec (long (Math/ceil (* (count xs) p))))))
(doseq [p *command-line-args*]
  (let [r (read-string (slurp p))]
    (prn :file p :samples (:samples r) :gpu (mapv #(select-keys (:compute %) [:native-dispatches :cpu-fallbacks]) (:backends r)))
    (doseq [[l rows] (sort-by key (group-by :lane (:rows r)))]
      (prn l (into {} (for [k [:ms :bytes :cpu-ms :render :gc-pause-ms :runqueue]] [k (mapv #(perc % (map k rows)) [0.5 0.95])]))))))
