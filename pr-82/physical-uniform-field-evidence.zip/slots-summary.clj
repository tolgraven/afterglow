(defn percentile [p xs] (nth (sort xs) (dec (long (Math/ceil (* p (count xs)))))))
(doseq [file *command-line-args*]
  (prn file)
  (let [data (read-string (slurp file))]
    (doseq [[reorder rows] data lane [0 1]]
      (prn reorder lane (into {} (for [k [:cpu-ms :bytes]] [k (mapv #(percentile % (map (fn [x] (get-in x [lane k])) rows)) [0.5 0.95])]))))))
