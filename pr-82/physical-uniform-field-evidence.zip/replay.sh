#!/usr/bin/env bash
set -eu
: "${TOLGLOW_ROOT:?set to paired Tolglow clone}"
: "${AFTERGLOW_ROOT:?set to Afterglow PR head}"
capture=$(cd "$(dirname "$0")" && pwd)
classpath=$(cd "$TOLGLOW_ROOT" && lein with-profile +benchmark,+native-gpu classpath)
export LIBGL_ALWAYS_SOFTWARE=1 MESA_SHADER_CACHE_DISABLE=true LP_NUM_THREADS=2
export VENUE_GPU_MS=60000 VENUE_MOVEMENT=cpu VENUE_WORKER_MS=5000
export VENUE_ORIGINAL_FRAME="$capture/original-frame.clj" VENUE_MATERIAL_FILE="$capture/mixed-material.clj"
java -Xms1400m -Xmx1400m -XX:ActiveProcessorCount=3 -cp "$classpath" clojure.main "$capture/physical-broadcast-full.clj" "$capture/native-results.edn" 16 40
java -Xmx1400m -XX:ActiveProcessorCount=3 -cp "$classpath" clojure.main "$capture/cpu-show.clj" "$capture/cpu-results.edn" 10000 20 32
java -Xmx500m -XX:ActiveProcessorCount=2 -cp "$classpath" clojure.main "$capture/slot-check.clj" "$capture/slot-results.edn"
