# Carrying uniform field tuples through local fixture packing

The Linux OpenJDK 21 capture used Mesa llvmpipe OpenGL 4.5, a matched CPU moving-head solver, native scene deadlines set to 60 s, 5 s effect worker deadlines and two software rasterizer threads. It used the two forks below in sibling checkouts. Every run captured in-memory ArtDMX, with sockets and devices closed.

* Tolglow 39defcc0cbc65d216a806a7ca818f6895df3f4aa
* Afterglow reference 844198c6510e32be28b6b6e51cb07724d4e98a41
* Afterglow candidate 44bf81812bb051b0e89dc47da691de1595edb648

The host created two identical 20,000-pixel sculpture scenes with 64 moving heads, mixed charted and uncharted fields, four overlapping optical volumes and eight higher-priority washes. Native shader execution/readback, fused submissions, worker scheduling and optical calculations run normally in both hosts. The pair runs alternate order for every frame. The reference uses public expanded results and the five previous master fixture-column functions (read from original-frame.clj in the original namespace to keep the same patch/program data). The candidate requests one fresh uniform tuple in its local renderer. The source-stride comparison runs both with the revised packing functions while varying the GPU representation.

The harness compares the model, effect intents and every ArtDMX byte for all 158 universes on every frame. Its existing selected-preview tolerance is 1e-9. A separate CPU-only 10k control runs both packing kernels on two instances of Tolglow’s independent output scheduler and checks each against a third scalar oracle. Slot probes compare every emitted double and presence flag on ordered and reversed targets. CPU and allocation counters on the native case include the show coordinator and named Afterglow GPU and renderer threads. Median and p95 are nearest rank. Observation uses an injected clock, a shared VM and software OpenGL.

Set TOLGLOW_ROOT and AFTERGLOW_ROOT to the candidate checkouts and DISPLAY to a desktop GL display (or start the script under xvfb-run). Install normal Leiningen/Mesa support, then run:

    bash replay.sh

Raw EDNs contain individual samples. The earlier prototype reports show why stride-only and partially boxed implementations were revised. The released control and forced-expanded revised-kernel captures distinguish physical packing gains from savings in GPU worker allocations. Actual GPU hardware, hardware timing at the default deadline and optical field performance on customer hardware remain unmeasured.

The review fix at c83375f354cfcee7add00f3e4445edbfa870b513 adds per-row gain expansion for mixed targets. reports/venue-broadcast-reviewed-smoke.edn is a second six-warmup/eight-measured-pair run against the updated source. All packets, model, intents and preview passed; 135 dispatches with no CPU fallback in each lane. The original full timings remain at 44bf818.
