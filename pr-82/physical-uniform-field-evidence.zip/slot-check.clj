(require '[afterglow.render.frame :as f] '[clojure.edn :as edn])
(import '[java.lang.management ManagementFactory] '[com.sun.management ThreadMXBean])
(def ^ThreadMXBean counter (ManagementFactory/getThreadMXBean))
(defn measure [f] (let [bytes (.getCurrentThreadAllocatedBytes counter) cpu (.getCurrentThreadCpuTime counter) start (System/nanoTime) result (f)]
                     {:cpu-ms (/ (- (.getCurrentThreadCpuTime counter) cpu) 1e6) :ms (/ (- (System/nanoTime) start) 1e6) :bytes (- (.getCurrentThreadAllocatedBytes counter) bytes)}))
(let [n 20064 ids (vec (range n)) width 3 stride 12
      values (double-array [0.24 0.2 0.17]) expanded (double-array (* width n))
      _ (dotimes [i (alength expanded)] (aset expanded i (aget values (rem i width))))
      source {:components width :slot 0 :attribute :color}
      base {:target-ids ids :opacity 1.0 :blend :replace}
      dest (mapv (fn [_] [(double-array (* n stride)) (boolean-array (* n stride))]) (range 2))
      lanes (fn [i indexed?]
              (let [tuple? (= i 1) buf (if tuple? values expanded)
                    col (assoc source :values buf :source-stride (if tuple? 0 width))
                    batch (assoc base :target-indices (when indexed? (int-array (reverse ids))) :columns [col])
                    [x y] (dest i)]
                #(#'f/merge-packed-batches! {::f/stride stride} x y [batch])))
      result (into {} (for [indexed? [false true]
                            :let [run (mapv #(lanes % indexed?) [0 1])
                                  trial (fn [i] (into {} (for [j (if (even? i) [0 1] [1 0])] [j (measure (run j))])))]]
                        (do (dotimes [i 48] (trial i))
                            (let [rows (mapv trial (range 96))]
                              (assert (java.util.Arrays/equals ^doubles (get-in dest [0 0]) ^doubles (get-in dest [1 0])))
                              (assert (java.util.Arrays/equals ^booleans (get-in dest [0 1]) ^booleans (get-in dest [1 1])))
                              [indexed? rows]))))]
  (spit (first *command-line-args*) (pr-str result)))
