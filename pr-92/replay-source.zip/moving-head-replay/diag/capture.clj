(ns diag.capture
  (:require [diag.trace :as trace] [tolglow.perf.output-deadlines :as deadlines]
            [tolglow.perf.admission-cost :as admission] [afterglow.render.presentation :as policy]
            [tolglow.effects.cadence :as cadence] [afterglow.runtime.keyframes :as keyframes] [tolglow.show :as show] [afterglow.output.scheduler :as scheduler]
            [cheshire.core :as json] [clojure.java.io :as io])
  (:import [java.time Duration Instant] [java.nio.file Paths] [jdk.jfr Recording]
           [jdk.jfr.consumer RecordingFile] [java.util.concurrent ConcurrentHashMap ConcurrentLinkedQueue]))
(def observed
  '{afterglow.runtime.engine/advance :engine
    afterglow.runtime.executor/map-work :workers
    afterglow.runtime.engine/assemble :merge-instances
    afterglow.render.frame/resolve-contributions :resolve-light
    afterglow.render.frame/resolve-partitioned :partition
    afterglow.render.frame/merge-packed-batches! :merge-packed
    afterglow.render.frame/merge-general-assignments! :merge-general
    afterglow.render.frame/general-targets :identify-general
    afterglow.render.coverage/plan :coverage
    afterglow.render.frame/pack-dense-state :pack-dmx
    afterglow.render.frame/pack-general-state :pack-general
    afterglow.render.layers/compose :compose
    afterglow.render.presentation/freeze-frame :freeze
    afterglow.render.presentation/materialize :wire-pack
    afterglow.render.presentation/present :choose-source
    tolglow.effects.cadence/finish :cadence
    tolglow.show/begin-presentation! :begin-packet
    tolglow.spatial/advance :spatial
    tolglow.show/prepare-compiler! :compiler
    afterglow.output.scheduler/complete! :complete})
(defn timed [kind f]
  (fn [& args] (if-not (.get trace/current) (apply f args)
                 (let [row (trace/begin-span kind false)]
                   (try (apply f args) (finally (trace/end-span! row)))))))
(defn with-slot [outer kind slot-fn]
  (fn [& args]
    (.set trace/current (slot-fn args))
    (let [row (trace/begin-span kind true)]
      (try (apply outer args) (finally (trace/end-span! row) (.remove trace/current))))))
(defn stamp [^Instant time]
  (+ trace/once-mono (.toNanos (Duration/between trace/once-utc time))))
(defn jfr-rows [path]
  (into [] (keep (fn [event]
                   (let [type (.getName (.getEventType event))
                         thread (if (= type "jdk.ExecutionSample") (.getThread event "sampledThread") (.getThread event))]
                     (when (or (not= type "jdk.ThreadPark") (and thread (re-matches #"pool-\d+-thread-\d+|afterglow-runtime-\d+" (.getJavaName thread))))
                       {:type type :tid (some-> thread .getJavaThreadId)
                        :start (stamp (.getStartTime event)) :end (stamp (.getEndTime event))
                        :stack (when (= type "jdk.ExecutionSample")
                                 (mapv (fn [frame] (let [m (.getMethod frame)]
                                                    (str (.getName (.getType m)) "." (.getName m))))
                                       (take 16 (.getFrames (.getStackTrace event)))))
                        :deopt (when (= type "jdk.Deoptimization") [(.getString event "reason") (.getString event "action") (some-> (.getValue event "method") .getName)])}))))
        (RecordingFile/readAllEvents path)))
(defn same-wire! [sources wires]
  (let [totals (frequencies
                (for [[frame-id universes] wires]
                  (let [expected (.get ^ConcurrentHashMap sources frame-id)]
                    (cond
                      expected (do (assert (= (keys expected) (keys universes)))
                                   (doseq [[u values] expected]
                                     (let [^bytes b (get universes u)]
                                       (dotimes [i (alength b)]
                                         (assert (= (nth values i) (bit-and 255 (aget b i))) [frame-id u i])))) :verified)
                      (zero? frame-id) (do (assert (every? #(every? zero? %) (vals universes))) :idle)
                      :else (throw (ex-info "Unknown emitted source" {:frame frame-id}))))))]
    {:packets totals :ordered-output-count (count wires)}))
(defn observed-cadence [observed finish session model elapsed]
  (let [result (finish session model elapsed)
        intervals (get-in session [:inputs :keyframe-intervals])
        samples @(:samples session)]
    (.add ^ConcurrentLinkedQueue observed
      {:slot (.get trace/current)
       :effects (into {} (for [[id {:keys [effect-id]}] (:instances model)]
                            [effect-id {:interval-ms (get-in intervals [id :ms])
                                        :calls (get-in samples [id :calls] 0)
                                        :cost-ms (get-in samples [id :total-ms])
                                        :eligible? (get-in samples [id :predictive?])
                                        :next-stride (get-in result [:state :effects id :stride])}]))})
    result))
(defn observed-keyframes [windows evaluate step ctx]
  (let [result (evaluate step ctx)]
    (.add ^ConcurrentLinkedQueue windows
          {:slot (.get trace/current) :effect (get-in ctx [:instance :effect-id])
           :window (boolean (::keyframes/window result))})
    result))
(defn run [output warmup slots]
  (let [path (Paths/get (str output ".jfr") (make-array String 0))
        vr (fn [id] (or (resolve id) (throw (ex-info "Missing stage" {:id id}))))
        stages (into {} (for [[id kind] observed :let [v (vr id)]] [v (timed kind @v)]))
        freeze (stages #'policy/freeze-frame)
        sources (ConcurrentHashMap.) wire (ConcurrentLinkedQueue.) samples (ConcurrentLinkedQueue.) windows (ConcurrentLinkedQueue.)
        capture-freeze (fn [metadata values] (let [frozen (freeze metadata values)]
                                              (.putIfAbsent sources (:frame-id frozen) (:universes frozen)) frozen))
        observe @#'deadlines/observe-sink
        sink (fn [clock rows] (let [{:keys [send!]} (observe clock rows)]
                               {:send! (fn [values id] (let [r (send! values id)]
                                                         (.add wire [id values]) r))}))
        vars (assoc stages #'policy/freeze-frame capture-freeze
                           #'keyframes/evaluate (partial observed-keyframes windows keyframes/evaluate)
                           #'cadence/finish (partial observed-cadence samples (stages #'cadence/finish))
                           #'show/render-slot! (with-slot show/render-slot! :render #(-> % second :slot))
                           #'scheduler/send-slot! (with-slot @#'scheduler/send-slot! :publication #(nth % 2))
                           #'deadlines/observe-sink sink)
        model (:model (admission/workload 1024 128))]
    (with-open [rec (Recording.)]
      (doseq [t ["jdk.GCPhasePause" "jdk.SafepointBegin" "jdk.SafepointEnd" "jdk.Deoptimization" "jdk.GCPhasePauseLevel1"]]
        (.enable rec t))
      (doseq [t ["jdk.ThreadPark" "jdk.JavaMonitorEnter" "jdk.Compilation"]]
        (.withThreshold (.enable rec t) (Duration/ofMillis 2)))
      (when (System/getenv "VENUE_SAMPLE_STACKS")
        (.withPeriod (.enable rec "jdk.ExecutionSample") (Duration/ofMillis 2)))
      (.start rec)
      (let [result (with-redefs-fn vars #(#'deadlines/run-case :pixel-sculpture model warmup slots 0))]
        (.stop rec) (.dump rec path)
        (let [stats (same-wire! sources wire) result (assoc result :clock-anchor {:monotonic-ns trace/once-mono :utc (str trace/once-utc) :bracket-ns (:span trace/anchor)} :spans (vec trace/spans) :sampling (vec samples) :windows (vec windows) :jfr (jfr-rows path) :wire-oracle stats)]
          (with-open [w (io/writer output)] (json/generate-stream result w))
          (prn (:summary result) stats))))))
(defn -main [output warmup slots] (run output (parse-long warmup) (parse-long slots)) (shutdown-agents))
