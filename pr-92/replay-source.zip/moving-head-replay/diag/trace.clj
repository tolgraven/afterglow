(ns diag.trace
  (:require [clojure.string :as str])
  (:import [com.sun.management ThreadMXBean] [java.lang.management ManagementFactory]
           [java.io RandomAccessFile] [java.time Instant]
           [java.util.concurrent ConcurrentLinkedQueue]))

(def ^ThreadMXBean mx (ManagementFactory/getThreadMXBean))
(def ^ThreadLocal current (ThreadLocal.))
(def ^ConcurrentLinkedQueue spans (ConcurrentLinkedQueue.))
(defn clock-anchor []
  (let [sample (fn [] (let [begin (System/nanoTime) utc (Instant/now) end (System/nanoTime)]
                        {:utc utc :span (- end begin) :mid (+ begin (quot (- end begin) 2))}))]
    (apply min-key :span (repeatedly 32 sample))))
(def anchor (clock-anchor))
(def once-mono (:mid anchor))
(def once-utc (:utc anchor))
(def ^ThreadLocal sched (proxy [ThreadLocal] []
                          (initialValue [] (try (RandomAccessFile. "/proc/thread-self/schedstat" "r")
                                                (catch Exception _ nil)))))
(defn schedwait []
  (when-let [^RandomAccessFile f (.get sched)]
    (.seek f 0)
    (parse-long (second (str/split (.readLine f) #" ")))))
(defn throttle []
  (try (let [s (slurp "/sys/fs/cgroup/cpu.stat")]
         (some-> (re-find #"(?m)^throttled_usec (\d+)$" s) second parse-long))
       (catch Exception _ nil)))
(defn cpu [] (.getCurrentThreadCpuTime mx))
(defn allocated [] (.getCurrentThreadAllocatedBytes mx))
(defn begin-span [kind full?]
  (let [s (when full? (schedwait)) q (when (#{:render :publication} kind) (throttle))]
    {:kind kind :tid (.threadId (Thread/currentThread))
     :start (System/nanoTime) :cpu0 (cpu) :bytes0 (allocated) :wait0 s :throttle0 q}))
(defn end-span! [row]
  (let [end (System/nanoTime) c (cpu) b (allocated)
        {:keys [start cpu0 bytes0 wait0 throttle0]} row
        w (when wait0 (schedwait)) q (when throttle0 (throttle))]
    (.add spans (cond-> (-> row (dissoc :cpu0 :bytes0 :wait0 :throttle0)
                         (assoc :slot (.get current) :end end :ms (/ (- end start) 1e6)
                                :cpu (/ (- c cpu0) 1e6) :allocated (- b bytes0)))
                  w (assoc :runnable-wait (/ (- w wait0) 1e6))
                  q (assoc :cgroup-throttled (/ (- q throttle0) 1e3))))))
(defn job [slot submitted id f input]
  (.set current slot)
  (let [started (System/nanoTime)
        row (assoc (begin-span :worker true) :effect id :dispatch-ns submitted :enter-ns started)]
    (try (f input) (finally (end-span! row) (.remove current)))))
