(require '[afterglow.render.frame :as frame])
(let [head {:id :moving :position [0 0 0] :universe 0 :address 1 :channels {:pan [1 2] :tilt [3 4]}
            :calibration {:pan {:min-deg -360 :max-deg 360} :tilt {:min-deg -90 :max-deg 90}}}
      direction [{:target-id :moving :attribute :direction :value [0 0 -1] :blend :replace}]]
  (doseq [previous [0.10 0.20 0.25 0.35 0.45 0.49 0.50 0.51 0.55 0.65 0.75 0.85 0.90]]
    (let [result (frame/resolve-frame [head] direction {:previous-values {:moving {:pan previous}}})
          values (get-in result [:values :moving])]
      (println previous (:pan values) (:aim-reachable? values)))))
