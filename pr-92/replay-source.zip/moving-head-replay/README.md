# Run the moving-head and physical frame comparisons locally

Use Linux, Java 21+, Leiningen, GNU patch and Python 3. The workload has 1,024 RGBW pixels and 128 moving heads. Every output interface is an in-memory capture. The physical clock is 40 Hz with two effect workers, a beat-driven wash, a moving aim and a pulse. The launcher exports the exact Tolglow and Afterglow source revisions named in `replay.sh` from your local Git clones. Fetch the PR branches or merged history first. Leiningen needs its standard dependencies.

```sh
TOLGLOW_ROOT=/path/to/tolglow AFTERGLOW_ROOT=/path/to/afterglow ./replay.sh ./results
```

The runner checks 2,464 calibration cases, then captures a baseline physical show with 120 warmup slots and 240 measured slots. Two independent hosts replay that run’s locally observed source clocks and effect intervals. They compare the original and shortened mechanical-angle selection on full 11-universe ArtDMX bytes, all 1,152 preview records, effect intents and show model. The runner also captures two additional physical shows to check the transport optimization from Afterglow #81 and the mechanical-angle optimization from #92. Set `MOTION_QUICK=1` to run just the synthetic calibration check. You can choose an available CPU affinity with `taskset` and enable JFR execution samples with `VENUE_SAMPLE_STACKS=1`.

Each physical capture records per-slot producer and publisher timing, each effect's requested interval and actual solver calls, worker queue time, CPU, runnable wait, nested lighting stages and garbage collection. Its wire oracle compares every emitted byte with the producer's immutable packets. The current source records a bracketed conversion between monotonic timestamps and JFR UTC at initialization. Stage timings overlap across threads. A shared cgroup's throttling counter covers other work using that cgroup. The first run also produces the independent clock corpus for the deterministic crossed comparison. Use `report.py` to inspect the new local compressed JSON captures. New results stay in the local directory you choose.
