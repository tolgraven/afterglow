(require '[tolglow.perf.admission-cost :as rig] '[tolglow.show :as show]
         '[tolglow.effects.cadence :as cadence] '[afterglow.render.frame :as frame]
         '[tolglow.bench-show :as bench] '[cheshire.core :as json] '[clojure.java.io :as io])
(import '[java.security MessageDigest] '[java.util HexFormat] '[java.util.zip GZIPInputStream]
        '[java.lang.management ManagementFactory])
(def original @#'frame/normalized-angle)
(in-ns 'afterglow.render.frame)
(load-file (System/getenv "VENUE_MOVEMENT_FRAGMENT"))
(in-ns 'user)
(def alternate @#'frame/normalized-angle)
(def frame-var #'frame/normalized-angle)
(defn by-record [begin schedule runtime before model]
  (let [sample (begin runtime before model)
        rates (into {} (for [[id {:keys [effect-id]}] (:instances model)
                             :let [rate (get-in schedule [(name effect-id) "interval-ms"])] :when rate]
                         [id {:ms rate}]))]
    (assoc-in sample [:inputs :keyframe-intervals] rates)))
(defn timed-compute [op rows]
  (let [^com.sun.management.ThreadMXBean t (ManagementFactory/getThreadMXBean)
        start (System/nanoTime) cpu (.getCurrentThreadCpuTime t) bytes (.getCurrentThreadAllocatedBytes t)
        result (op)]
    (vswap! rows assoc :pack-cpu-ms (/ (- (.getCurrentThreadCpuTime t) cpu) 1e6)
            :pack-bytes (- (.getCurrentThreadAllocatedBytes t) bytes) :pack-ms (/ (- (System/nanoTime) start) 1e6))
    result))
(defn replay-one [host time intervals solver sinks pack]
  (let [timing (volatile! {}) sink (:sink host)
        opts {frame-var solver #'cadence/begin (partial by-record cadence/begin intervals)
              #'frame/pack-dense-state (fn [& args] (timed-compute #(apply pack args) timing))}
        before (System/nanoTime)]
    (with-redefs-fn opts #(show/tick! host time))
    (let [elapsed (/ (- (System/nanoTime) before) 1e6)
          {:keys [output model status]} @(:state host)
          preview (frame/project-compact (:compact output) (range 1152))]
      (assert (not (or (:error status) (:output-error status))))
      {:model model :intents (:last-intents status) :packets @(:latest sink) :preview preview
       :metrics (assoc @timing :whole-ms elapsed)})))
(let [[capture output] *command-line-args*
      input (with-open [r (io/reader (GZIPInputStream. (io/input-stream capture)))] (json/parse-stream r))
      renders (sort-by #(get % "slot") (filter #(and (get % "show-time-ms") (<= (get % "slot") 360)) (get input "renders")))
      samples (into {} (map (juxt #(get % "slot") #(get % "effects")) (get input "sampling")))
      model (:model (rig/workload 1024 128))
      open #(show/create-runtime {:model model :workers 2 :workspace-options nil :batch? true :adaptive-keyframes {:enabled? true}
                                  :sink (bench/capture-sink) :worker-timeout-ms 5000 :frame-rate 40 :independent-output? false})
      hosts [(open) (open)] digest (MessageDigest/getInstance "SHA-256")
      pack @#'frame/pack-dense-state]
  (try
    (let [rows (reduce (fn [rows row]
                         (let [slot (get row "slot") time (get row "show-time-ms")
                               physical (bit-and (quot slot 2) 1)
                               result (into {} (for [lane (if (odd? slot) [1 0] [0 1])]
                                                 [lane (replay-one (hosts (bit-xor physical lane)) time
                                                                   (samples slot) ([original alternate] lane) nil pack)]))
                               a (result 0) b (result 1)]
                           (bench/check! a b)
                           (assert (= (:preview a) (:preview b)))
                           (doseq [^bytes packet (:packets a)] (.update digest packet))
                           (if (<= slot 120) rows (conj rows [slot (:metrics a) (:metrics b)])))) [] renders)
          proof {:frames (count renders) :timed (count rows) :artdmx-sha256 (.formatHex (HexFormat/of) (.digest digest)) :rows rows}]
      (with-open [w (io/writer output)] (json/generate-stream proof w))
      (prn (dissoc proof :rows)))
    (finally (run! show/stop! hosts) (shutdown-agents))))
