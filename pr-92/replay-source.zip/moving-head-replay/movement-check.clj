(require '[afterglow.render.frame :as frame])
(def original @#'frame/normalized-angle)
(in-ns 'afterglow.render.frame)
(load-file (System/getenv "VENUE_MOVEMENT_FRAGMENT"))
(in-ns 'user)
(def candidate @#'frame/normalized-angle)
(import '[java.lang.management ManagementFactory])
(def mx (ManagementFactory/getThreadMXBean))
(def cases
  (vec (for [axis [:pan :tilt]
             spec [nil [-0.0 -2.0] [1/3 -1/2] [0.0 0.0000000000001] [127.0 128.0] [255 200]
                   {:min-deg -90.0 :max-deg 90.0} {:min-deg -180 :max-deg 180} {:min-deg -270.0 :max-deg 270.0}
                   {:min-deg 1e12 :max-deg (+ 1e12 0.125)} {:min-deg 300M :max-deg 360M}]
             ang [-360.0 -270.0 -180.0 -179.99999999999997 -135.0 -90.0 -45.0 -0.0 0.0 1e-30 90.0 135.0 179.99999999999997 180.0 270.0 360.0]
             prev [nil 0.0 0.12345 0.25 0.5 0.75 1.0]]
         [(if spec {:calibration {axis spec}} {}) axis ang prev])))
(doseq [args cases]
  (let [a (apply original args) b (apply candidate args)] (assert (= a b) [args a b])
    (assert (= (Double/doubleToLongBits (double (:value a))) (Double/doubleToLongBits (double (:value b)))))))
(println :cases (count cases))
(defn benchmark [f pairs]
  (let [start (.getCurrentThreadCpuTime mx) bytes (.getCurrentThreadAllocatedBytes ^com.sun.management.ThreadMXBean mx)
        result (reduce (fn [sum [angle prev]]
                         (+ sum (double (:value (f {} :pan angle prev))) (double (:value (f {} :tilt angle prev)))))
                       0.0 pairs)]
    [result (/ (- (.getCurrentThreadCpuTime mx) start) 1e6)
     (- (.getCurrentThreadAllocatedBytes ^com.sun.management.ThreadMXBean mx) bytes)]))
(let [pairs (vec (for [i (range 10000)] [(- (/ (mod (* 117 i) 36000) 100.0) 180.0) (/ (mod (* 53 i) 1000) 999.0)]))
      captures (vec (for [i (range 38)] (into {} (for [l (if (odd? i) [0 1] [1 0])] [l (benchmark ([original candidate] l) pairs)]))))
      measured (drop 10 captures)]
  (assert (every? #(= (ffirst (vals %)) (first (second (vals %)))) captures))
  (doseq [l (range 2) k [1 2]]
    (let [xs (sort (map #(get-in % [l k]) measured))]
      (println :lane l :metric k :median (nth xs 13) :p95 (nth xs 26)))))
(shutdown-agents)
