from collections import defaultdict
from pathlib import Path
import gzip,json,statistics as s,sys,math
def percentile(v,p):
 return sorted(v)[math.ceil(len(v)*p)-1] if v else 0
def union_ms(intervals,start,end):
 cursor=start; occupied=0
 for a,b in sorted(intervals):
  a=max(a,cursor,start); b=min(b,end)
  if b>a: occupied+=b-a; cursor=b
 return occupied/1e6
def on_file(path):
 with gzip.open(path,'rt') as f: d=json.load(f)
 renders={r['slot']:r for r in d['renders'] if 121<=r['slot']<=360}
 outputs={r['slot']:r for r in d['outputs'] if 121<=r['slot']<=360}
 stages=defaultdict(lambda:defaultdict(list))
 for item in d['spans']:
  if item['slot'] is not None: stages[item['slot']][item['kind']].append(item)
 gc=[(j['start'],j['end']) for j in d['jfr'] if j['type']=='jdk.GCPhasePause']
 rows=[]; send=[]
 cadence={r['slot']:r for r in d.get('sampling',[])}
 windows=defaultdict(dict)
 for w in d.get('windows',[]): windows[w['slot']][w['effect']]=w['window']
 for num,timing in renders.items():
  ss=stages[num]
  if not ss['render']: continue
  own=ss['render'][0]
  # Engine and mapper overlap. Queue is submission to worker invocation; jobs overlap.
  jobs=ss['worker']
  row={'slot':num,'cost':timing['cost-ms'],'wake':timing['wake-lag-ms'],'lead':timing['lead-ms'],
       'sampling':{k:(v['interval-ms'],v['calls'],windows[num].get(k)) for k,v in cadence.get(num,{}).get('effects',{}).items()},'slack':timing['slack-ms'],'ownerWall':own['ms'],'ownerCPU':own['cpu'],
       'ownerWait':own.get('runnable-wait',0),'cgroup':own.get('cgroup-throttled',0),
       'GC':union_ms(gc,own['start'],own['end']),'jobs':len(jobs),
       'maxQueue':max([(j['enter-ns']-j['dispatch-ns'])/1e6 for j in jobs] or [0]),
       'maxJobWall':max([j['ms'] for j in jobs] or [0]),'workerCPU':sum(j['cpu'] for j in jobs),
       'maxWorkerWait':max([j.get('runnable-wait',0) for j in jobs] or [0]),
       'workerDetails':[(j['effect'],round(j['cpu'],3),round(j['ms'],3),round((j['enter-ns']-j['dispatch-ns'])/1e6,3),round(j.get('runnable-wait',0),3)) for j in jobs]}
  for key in ['engine','workers','merge-instances','resolve-light','partition','merge-general','merge-packed','identify-general','coverage','pack-dmx','pack-general','compose','freeze','wire-pack','complete','cadence']:
   parts=[a for a in ss[key] if a['tid']==own['tid'] and a['start']>=own['start'] and a['end']<=own['end']]
   if parts: row[key]=round(sum(a['ms'] for a in parts),3);row[key+'CPU']=round(sum(a['cpu'] for a in parts),3)
  row['owner-mb']=own['allocated']/1e6
  row['freeze-mb']=sum(j['allocated'] for j in ss['freeze'] if j['tid']==own['tid'] and j['start']>=own['start'] and j['end']<=own['end'])/1e6
  rows.append(row)
 for n,t in outputs.items():
  ss=stages[n]; own=next(iter(ss['publication']),{})
  send.append({'slot':n,'ms':t['finished-at-ms']-t['started-at-ms'],'wake':t['started-at-ms']-t['deadline-ms'],
               'pack':sum(j['ms'] for j in ss['wire-pack']),'choose':sum(j['ms'] for j in ss['choose-source']),
               'pack-mb':sum(j['allocated'] for j in ss['wire-pack'])/1e6,'ownerWait':own.get('runnable-wait',0),
               'CPU':own.get('cpu',0),'callback':t['sent-by-ms']-t['sent-at-ms'] if t.get('sent-at-ms') is not None else 0})
 print(Path(path).stem,d['summary'],d['wire-oracle'])
 def rnd(data):return {k:(round(v,3) if isinstance(v,float) else v) for k,v in data.items()}
 print('frame p50 p95 max:')
 for k in ['cost','ownerCPU','workerCPU','maxJobWall','ownerWait','maxWorkerWait','maxQueue','GC','cgroup','owner-mb','freeze-mb','workers','resolve-light','pack-dmx','freeze','cadence']:
  vs=[r[k] for r in rows if k in r]; print(k,','.join(str(round(percentile(vs,p),3)) for p in [.5,.95,1]))
 if cadence:
  from collections import Counter
  print('sampling per effect (interval-ms,calls,window):', {k:Counter(tuple(r['sampling'][k]) for r in rows if k in r['sampling']) for k in ['wash','steer','pulse']})
 print('worst render:')
 for r in sorted(rows,key=lambda r:-r['cost'])[:5]: print(rnd(r))
 print('worst pub:')
 for r in sorted(send,key=lambda r:-r['ms'])[:3]: print(rnd(r))
 print('publication p50/p95/max:')
 for k in ['ms','pack','pack-mb','callback','ownerWait']:
  vs=[r[k] for r in send];print(k,','.join(str(round(percentile(vs,p),3)) for p in [.5,.95,1]))
for path in sys.argv[1:]: on_file(path)
