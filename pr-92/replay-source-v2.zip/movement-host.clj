(require '[tolglow.perf.admission-cost :as rig] '[tolglow.show :as show]
         '[tolglow.effects.cadence :as cadence] '[afterglow.render.frame :as frame]
         '[tolglow.bench-show :as bench] '[cheshire.core :as json] '[clojure.java.io :as io])
(import '[java.security MessageDigest] '[java.util HexFormat] '[java.util.zip GZIPInputStream]
        '[java.lang.management ManagementFactory])
(def original @#'frame/normalized-angle)
(in-ns 'afterglow.render.frame)
(load-file (System/getenv "VENUE_MOVEMENT_FRAGMENT"))
(in-ns 'user)
(def alternate @#'frame/normalized-angle)
(def frame-var #'frame/normalized-angle)
(defn by-record [begin schedule runtime before model]
  (let [sample (begin runtime before model)
        rates (into {} (for [[id {:keys [effect-id]}] (:instances model)
                             :let [rate (get-in schedule [(name effect-id) "interval-ms"])] :when rate]
                         [id {:ms rate}]))]
    (assoc-in sample [:inputs :keyframe-intervals] rates)))
(defn timed-compute [op rows]
  (let [^com.sun.management.ThreadMXBean t (ManagementFactory/getThreadMXBean)
        start (System/nanoTime) cpu (.getCurrentThreadCpuTime t) bytes (.getCurrentThreadAllocatedBytes t)
        result (op)]
    (vswap! rows assoc :pack-cpu-ms (/ (- (.getCurrentThreadCpuTime t) cpu) 1e6)
            :pack-bytes (- (.getCurrentThreadAllocatedBytes t) bytes) :pack-ms (/ (- (System/nanoTime) start) 1e6))
    result))
(defn replay-one [host time intervals solver pack]
  (let [timing (volatile! {}) sink (:sink host)
        opts {frame-var solver #'cadence/begin (partial by-record cadence/begin intervals)
              #'frame/pack-dense-state (fn [& args] (timed-compute #(apply pack args) timing))}
        before (System/nanoTime)]
    (with-redefs-fn opts #(show/tick! host time))
    (let [elapsed (/ (- (System/nanoTime) before) 1e6)
          {:keys [output model status]} @(:state host)
          preview (frame/project-compact (:compact output) (range 1152))]
      (assert (not (or (:error status) (:output-error status))))
      {:model model :intents (:last-intents status) :packets @(:latest sink) :preview preview
       :metrics (assoc @timing :whole-ms elapsed)})))
(defn read-corpus [capture]
  (with-open [reader (io/reader (GZIPInputStream. (io/input-stream capture)))]
    (let [data (json/parse-stream reader)
          by-slot (into {} (map (juxt #(get % "slot") #(get % "effects"))) (get data "sampling"))
          frame (fn [row]
                  (let [slot (get row "slot")
                        time (get row "show-time-ms")]
                    (when (and time (get row "ready-at-ms") (<= slot 360))
                      {:slot slot :time time :intervals (by-slot slot)})))]
      (sort-by :slot (keep frame (get data "renders"))))))

(defn open-host [model]
  (show/create-runtime {:model model :workers 2 :batch? true :frame-rate 40
                        :adaptive-keyframes {:enabled? true}
                        :sink (bench/capture-sink) :independent-output? false
                        :worker-timeout-ms 5000 :workspace-options nil}))

(defn compare-frame! [hosts ^MessageDigest digest pack {:keys [slot time intervals]}]
  (let [offset (bit-and (quot slot 2) 1)
        compare-lane (fn [lane]
                       (let [host (hosts (bit-xor offset lane))
                             solver ([original alternate] lane)]
                         [lane (replay-one host time intervals solver pack)]))
        order (if (odd? slot) [1 0] [0 1])
        {before 0 after 1} (into {} (map compare-lane) order)]
    (bench/check! before after)
    (assert (= (:preview before) (:preview after)))
    (doseq [^bytes packet (:packets before)]
      (.update digest packet))
    (when (> slot 120)
      [slot (:metrics before) (:metrics after)])))

(defn write-comparison! [hosts corpus output]
  (let [digest (MessageDigest/getInstance "SHA-256")
        compare! (partial compare-frame! hosts digest @#'frame/pack-dense-state)
        rows (into [] (keep compare!) corpus)
        checksum (.formatHex (HexFormat/of) (.digest digest))
        summary {:frames (count corpus) :timed (count rows) :artdmx-sha256 checksum}]
    (with-open [writer (io/writer output)]
      (json/generate-stream (assoc summary :rows rows) writer))
    (prn summary)))

(let [[capture output] *command-line-args*
      corpus (read-corpus capture)]
  (when-not (some #(> (:slot %) 120) corpus)
    (throw (ex-info "No completed measured frame is available for comparison" {})))
  (let [model (:model (rig/workload 1024 128))
        first-host (open-host model)]
    (try
      (let [second-host (open-host model)]
        (try
          (write-comparison! [first-host second-host] corpus output)
          (finally (show/stop! second-host))))
      (finally
        (show/stop! first-host)
        (shutdown-agents)))))
