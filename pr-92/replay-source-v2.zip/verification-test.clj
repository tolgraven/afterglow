(require '[clojure.test :refer [deftest is run-tests]]
         '[diag.verification :as verify])

(deftest failed-physical-oracle-retains-the-original-exception
  (let [renders [{:ready-at-ms 99 :slack-ms 1 :deadline-ms 100}]
        attempts [{:slot 121 :deadline-ms 100 :source-time-ms 100 :sent-at-ms 101}
                  {:slot 122 :deadline-ms 125 :source-time-ms 100 :sent-at-ms 103}]
        failure (volatile! nil)
        oracle (fn [& _] (throw (ex-info "spacing" {:wire 2})))
        run! (verify/recording oracle failure)]
    (run! renders attempts [{:bytes [255]}] 120 2)
    (is (= {:wire 2} (:data @failure)))
    (is (= [{:before 101 :after 103 :gap-ms 2}] (get-in @failure [:conditions :short-admission-gaps])))
    (is (true? (get-in @failure [:conditions :lit-output])))
    (is (empty? (get-in @failure [:conditions :unknown-sources])))))

(deftest failed-wire-oracle-retains-channel-and-packet
  (let [source {42 {1 [255 0]}}
        capture (fn [frame & values] [[frame {1 (byte-array (map unchecked-byte values))}]])]
    (is (= {:packets {:verified 1} :ordered-output-count 1}
           (verify/wire-report source (capture 42 255 0))))
    (is (= {:frame 42 :universe 1 :channel 2 :expected 0 :actual 2}
           (get-in (verify/wire-report source (capture 42 255 2)) [:failure :data])))
    (is (= {:frame 42 :universe 1 :expected 2 :actual 1}
           (get-in (verify/wire-report source (capture 42 255)) [:failure :data])))
    (is (= {:frame 41} (get-in (verify/wire-report source (capture 41 255)) [:failure :data])))
    (is (= {:frame 0} (get-in (verify/wire-report source (capture 0 255)) [:failure :data])))
    (is (= {:idle 1} (:packets (verify/wire-report source (capture 0 0 0)))))))

(deftest save-before-reporting-failure
  (doseq [data [{:physical-verification {:message "late output"}}
                {:wire-oracle {:failure {:message "bad output"}}}]]
    (let [saved (volatile! nil)]
      (is (thrown? clojure.lang.ExceptionInfo (verify/save-checked! #(vreset! saved %) data)))
      (is (= data @saved))))
  (let [saved (volatile! nil)]
    (is (nil? (verify/save-checked! #(vreset! saved %) {:verified true})))
    (is (= {:verified true} @saved))))

(let [{:keys [fail error]} (run-tests)]
  (when (pos? (+ fail error)) (System/exit 1)))
