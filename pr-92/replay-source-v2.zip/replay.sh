#!/usr/bin/env bash
set -euo pipefail
kit=$(cd "$(dirname "$0")" && pwd)
: "${TOLGLOW_ROOT:?Set TOLGLOW_ROOT to the local Tolglow checkout}"
: "${AFTERGLOW_ROOT:?Set AFTERGLOW_ROOT to the local Afterglow checkout}"
results=${1:-./physical-results}
mkdir -p "$results"
results=$(cd "$results" && pwd)
if compgen -G "$results/movement-*" >/dev/null; then
  echo "Use a fresh results directory; this one contains replay results." >&2
  exit 2
fi
for lane in original packet motion; do
  if compgen -G "$results/$lane.*" >/dev/null; then
    echo "Use a fresh results directory; this one contains $lane results." >&2
    exit 2
  fi
done
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
mkdir -p "$work/t" "$work/a" "$work/trace/afterglow/runtime" "$work/packet/afterglow/render" "$work/motion/afterglow/render" "$work/jfr"
git -C "$TOLGLOW_ROOT" archive c25dc4b377b5c9517619e8988bf1f72187265085 | tar -x -C "$work/t"
git -C "$AFTERGLOW_ROOT" archive 84b3821a27099efdb5cb95c69eba442549523b0e | tar -x -C "$work/a"
git -C "$AFTERGLOW_ROOT" show 403b36def280118993e722cf4b877edccb559069:src/afterglow/render/frame.clj > "$work/motion/afterglow/render/frame.clj"
git -C "$AFTERGLOW_ROOT" diff 4769e27^ 4769e27 -- src/afterglow/render/presentation.clj > "$work/packet.patch"
cp "$work/a/src/afterglow/render/presentation.clj" "$work/packet/afterglow/render/"
(cd "$work/packet" && patch -s -p2 < "$work/packet.patch")
(cd "$work/t" && AFTERGLOW_ROOT="$work/a" lein with-profile +benchmark classpath > "$work/classpath")
python3 - "$work" <<'PY'
from pathlib import Path
import sys
base=Path(sys.argv[1]); rel='afterglow/runtime/executor.clj'; s=(base/'a/src'/rel).read_text()
s=s.replace('  (:import ', '  (:require [diag.trace :as trace])\n  (:import ',1)
original='(let [task (proxy [FutureTask] [(reify Callable (call [_] (f job)))]'
assert s.count(original)==1
s=s.replace(original,'''(let [slot (.get ^ThreadLocal trace/current) dispatched (System/nanoTime)
                            task (proxy [FutureTask] [(reify Callable (call [_] (trace/job slot dispatched (get-in job [:instance :effect-id]) f job)))]''')
(base/'trace'/rel).write_text(s)
PY
export VENUE_MOVEMENT_FRAGMENT="$kit/movement-fragment.clj"
cp_base=$(cat "$work/classpath")
java_opts=(-Djava.awt.headless=true -XX:ActiveProcessorCount=4 -Xms768m -Xmx768m "-XX:FlightRecorderOptions=repository=$work/jfr")
run_java() { java "${java_opts[@]}" -cp "$1:$kit:$cp_base" clojure.main "${@:2}"; }
run_java "$kit" "$kit/verification-test.clj"
run_java "$kit" "$kit/movement-check.clj" > "$results/movement-check.log"
if [[ "${MOTION_QUICK:-0}" == 1 ]]; then exit 0; fi
failure=0
for lane in original packet motion; do
  layers="$work/trace"
  if [[ "$lane" != original ]]; then layers="$work/$lane:$layers"; fi
  if ! run_java "$layers" -m diag.capture "$results/$lane.json" 120 240 > "$results/$lane.log" 2>&1; then
    echo "Failed physical verification or startup in $lane. See $results/$lane.log." >&2
    failure=1
  fi
  if [[ ! -s "$results/$lane.json" ]]; then continue; fi
  gzip -f "$results/$lane.json"
  if ! python3 "$kit/report.py" "$results/$lane.json.gz" > "$results/$lane.summary"; then
    echo "The trace is saved; report generation failed for $lane." >&2
    failure=1
  fi
  if [[ "$lane" == original ]]; then
    if ! run_java "$kit" "$kit/movement-host.clj" "$results/original.json.gz" "$results/movement-pair.json" > "$results/movement-pair.log" 2>&1; then
      echo "Failed the matched-frame comparison. See $results/movement-pair.log." >&2
      failure=1
    fi
  fi
done
exit "$failure"
