(ns diag.verification)

(defn- descending [times]
  (filter (fn [[a b]] (> a b)) (partition 2 1 times)))

(defn- short-spacing [times]
  (keep (fn [[a b]]
          (let [gap (- b a)]
            (when (< gap 12.49)
              {:before a :after b :gap-ms gap})))
        (partition 2 1 times)))

(defn details [renders outputs wire warmup slots]
  (let [in-window? #(<= (inc warmup) (:slot %) (+ warmup slots))
        measured (filter in-window? outputs)
        on-time? #(and (:ready-at-ms %) (not (neg? (:slack-ms %))))
        ready (into #{} (comp (filter on-time?) (map :deadline-ms)) renders)
        source-times (keep :source-time-ms measured)
        delivered (filter :sent-at-ms measured)]
    {:rendered (count renders)
     :measured-attempts (count measured)
     :has-source (boolean (seq source-times))
     :unknown-sources (vec (remove ready source-times))
     :out-of-order (vec (descending source-times))
     :late-admissions (mapv :slot (filter #(>= (:sent-at-ms %) (+ 25 (:deadline-ms %))) delivered))
     :short-admission-gaps (vec (short-spacing (map :sent-at-ms delivered)))
     :lit-output (boolean (some #(some pos? (:bytes %)) wire))}))

(defn recording [verify failure]
  (fn [renders outputs wire warmup slots]
    (try
      (verify renders outputs wire warmup slots)
      (catch clojure.lang.ExceptionInfo cause
        (vreset! failure {:message (ex-message cause)
                          :data (ex-data cause)
                          :conditions (details renders outputs wire warmup slots)})))))

(defn- check-universe! [frame universe expected ^bytes actual]
  (let [size (alength actual)
        location {:frame frame :universe universe}]
    (when-not (= (count expected) size)
      (throw (ex-info "Universe length changed" (assoc location :expected (count expected) :actual size))))
    (dotimes [index size]
      (let [command (nth expected index)
            delivered (bit-and 255 (aget actual index))]
        (when-not (= command delivered)
          (throw (ex-info "Channel value changed"
                          (assoc location :channel (inc index) :expected command :actual delivered))))))))

(defn- check-frame! [sources [frame universes]]
  (if-let [expected (get sources frame)]
    (do
      (when-not (= (set (keys expected)) (set (keys universes)))
        (throw (ex-info "Universe set changed" {:frame frame :expected (keys expected) :actual (keys universes)})))
      (run! (fn [[u values]] (check-universe! frame u values (get universes u))) expected)
      :verified)
    (if (zero? frame)
      (do
        (when-not (every? #(every? zero? %) (vals universes))
          (throw (ex-info "Idle output contains light" {:frame frame})))
        :idle)
      (throw (ex-info "Unknown emitted source" {:frame frame})))))

(defn wire-report [sources wires]
  (try
    {:packets (frequencies (map (partial check-frame! sources) wires))
     :ordered-output-count (count wires)}
    (catch clojure.lang.ExceptionInfo cause
      {:failure {:message (ex-message cause) :data (ex-data cause)}})))

(defn save-checked! [write! result]
  (write! result)
  (let [physical (:physical-verification result)
        wire (get-in result [:wire-oracle :failure])]
    (when (or physical wire)
      (throw (ex-info "Replay verification failed. Local trace retained."
                      {:physical physical :wire wire})))))
