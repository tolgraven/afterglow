#!/usr/bin/env bash
set -euo pipefail
: "${AFTERGLOW_ROOT:?set to a checkout at Afterglow PR 85 head 902c0e0}"
: "${TOLGLOW_ROOT:?set to a checkout at Tolglow fef01db4}"
dir=$(cd "$(dirname "$0")" && pwd)
out=${1:-"$dir/replay"}
mkdir -p "$out/src/afterglow/render/gpu"
test "$(git -C "$AFTERGLOW_ROOT" rev-parse HEAD)" = 902c0e09e002d8fa60de58417f96134d0d57ccca
test "$(git -C "$TOLGLOW_ROOT" rev-parse HEAD)" = fef01db4a5804559f90f82147dd94c7c19bdfa16
for path in compute fields frame gpu/session hdr; do
  git -C "$AFTERGLOW_ROOT" show "c83375f354cfcee7add00f3e4445edbfa870b513:src/afterglow/render/$path.clj" > "$out/src/afterglow/render/$path.clj"
done
git -C "$AFTERGLOW_ROOT" show 4769e27c4b803c7a4a9f8ed9cd010ae5ddc0039b:src/afterglow/render/presentation.clj > "$out/src/afterglow/render/presentation.clj"
entries=$(cd "$TOLGLOW_ROOT" && lein with-profile +benchmark,+native-gpu classpath)
bench_cp="$out/src:$entries"
export LIBGL_ALWAYS_SOFTWARE=1 MESA_SHADER_CACHE_DISABLE=true LP_NUM_THREADS=2
export VENUE_GPU_MS=60000 VENUE_MOVEMENT=cpu VENUE_WORKER_MS=5000
export VENUE_MATERIAL_FILE="$dir/mixed-material.clj" VENUE_WEIGHT_FORMS="$dir/weight-forms.clj"
java -Xmx180m -XX:ActiveProcessorCount=2 -cp "$bench_cp" clojure.main "$dir/weight-controls.clj" "$out/controls.edn"
for size in 10000 20000; do
  VENUE_PIXELS=$size java -Xms1400m -Xmx1400m -XX:ActiveProcessorCount=3 -cp "$bench_cp" clojure.main "$dir/native-weight-scan.clj" "$out/$size.edn" 18 40
done
python3 "$dir/weight-rows.py" "$out/10000.edn" "$out/20000.edn"
VENUE_PIXELS=20000 java -Xms1450m -Xmx1450m -XX:ActiveProcessorCount=3 -cp "$bench_cp" clojure.main "$dir/native-weight-direct.clj" "$out/direct.edn" 12 24
