from pathlib import Path
import re,sys,math
for file in sys.argv[1:]:
 data=Path(file).read_text();r=data.split(':rows [')[1].split('], :traffic')[0]
 d=[dict((k,float(v)) for k,v in re.findall(r':([a-z0-9-]+)\s+([0-9.eE+-]+)',s)) for s in re.findall(r'\{([^{}]+)\}',r)]
 print(file)
 for lane in [0,1]:
  rows=[x for x in d if x.get('lane')==lane]
  def p(k,f):return sorted(x[k] for x in rows)[math.ceil(f*len(rows))-1]
  print(lane,{k:[round(p(k,f),2) for f in (.5,.95)] for k in ('ms','cpu-ms','bytes','weight-check-bytes','weight-check-cpu-ms','weights-checked')},'seq',len(rows))
 print(re.search(r':artdmx-sha256 "(.*?)"',data)[1], 'fallback',re.findall(r':cpu-fallbacks (\d+)',data))
