[(defn- validate-weights! [weights source]
  (when (and (some? weights) (not (and (map? weights) (every? unit? (vals weights)))))
    (throw (faults/attributed-error (ex-info "Target weights must be a map of unit opacities" {}) source))))


(defn- direct-group [blocks]
  (let [members (ordered-members blocks)
        ordered (vec (mapcat (fn [member] (check-member! member) member) members))
        {:keys [target-weights opacity] :or {opacity 1}} (:native-layer (first ordered))]
    (when (every? physical-replacement? ordered)
      (cond
        (nil? target-weights)
        (when (opaque? opacity) (mapv #(dissoc % :native-layer) ordered))

        (or (zero? opacity) (empty? target-weights)) []

        (and (packed-factor? opacity) (every? packed-factor? (vals target-weights))
             (or (= 1 (count ordered)) (independent-columns? ordered)))
        (let [masked (mapv (fn [block]
                             ((if (= :batch (:kind block)) masked-batch masked-assignments)
                              block target-weights opacity))
                           ordered)]
          (when (every? some? masked) masked))))))

]