(require '[afterglow.render.layers :as layers])
(import '[com.sun.management ThreadMXBean] '[java.lang.management ManagementFactory])
(def ^ThreadMXBean counter (ManagementFactory/getThreadMXBean))
(defn reference [predicate weights] (every? predicate (vals weights)))
(defn reduced-weights [predicate weights]
  (reduce-kv (fn [_ _ value] (if (predicate value) true (reduced false))) true weights))
(defn view [check weights]
  [(check @#'layers/unit? weights) (check @#'layers/packed-factor? weights)])
(defn run [f]
  (let [cpu (.getCurrentThreadCpuTime counter) allocated (.getCurrentThreadAllocatedBytes counter)
        value (f)]
    [value {:us (/ (- (.getCurrentThreadCpuTime counter) cpu) 1000.0)
            :bytes (- (.getCurrentThreadAllocatedBytes counter) allocated)}]))
(defn pairs [weights count]
  (mapv (fn [i]
          (let [order (if (even? i) [reference reduced-weights] [reduced-weights reference])
                [[a m0] [b m1]] (mapv #(run (fn [] (view % weights))) order)]
            (assert (= a b))
            (case (mod i 2) 0 [m0 m1] [m1 m0])))
        (range count)))
(let [large (into {} (map (fn [i] [(if (even? i) i (str i)) (/ (mod i 100) 100.0)])) (range 12000))
      cases {:all large :empty {} :sorted (sorted-map 0 0M 1 1M 2 0.5M)
             :bounds {:a 0 :b 1 :c (float 1.0)} :ratio {:r 1/3} :nil-value {:a nil}
             :decimal-over-one {:a 1.000000000000000000000001M}
             :nonfinite {:hot Double/POSITIVE_INFINITY} :nan {:a Double/NaN}}
      facts (update-vals cases (fn [m] (let [expected (view reference m)]
                                         (assert (= expected (view reduced-weights m)))
                                         expected)))]
  (pairs large 32)
  (spit (first *command-line-args*) (pr-str {:cases facts :rows (pairs large 70)})))
