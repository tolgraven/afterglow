# Lighting benchmark for a MacBook Air

From a local terminal or a Local Codex task, enter the extracted directory and run the launcher.

```sh
./run.sh all
```

The command runs three independent lanes in order and makes a time-stamped directory under `lighting-benchmark-results/` in the current directory. A failed lane leaves its log and the next lane still runs. `status.tsv` records all three exit statuses. Each run uses a new directory. The rig outputs only to an in-memory ArtDMX sink.

The default CPU and GPU-show workloads each have 20,000 RGBW pixels, 64 moving heads, eight washes and four moving spheres that select fixtures with smoothly fading edges. Two independent show hosts render the same timeline. One uses the original surface-intersection function and the other can skip it for a beam wholly inside a clear receiver cell. They alternate which host renders first. Both use two Clojure workers and compare every committed model, effect operation, ordered fixture event and ArtDMX buffer. Only after 18 warmup pairs do they take their 36 timed pairs.

1. `cpu` computes the full show on the JVM, including beam geometry and fixture packing. The two host lanes measure the same workload.
2. `gpu` runs a separate native OpenGL transform-feedback shader on one vertex per pixel. It computes RGB and focus, waits on the driver fence, reads four float32 values per vertex and verifies every one against an independent Clojure evaluation. At the default size each measured draw reads 320,000 bytes. The CPU oracle and validation run outside the GPU timer.
3. `gpu-show` repeats the whole-show comparison with native shader dispatch for the material and CPU moving-head geometry. It checks the actual GL renderer, verifies that both hosts drew and read GPU data and rejects any runtime fallback. The GPU budget is relaxed for these diagnostic runs. The measured 25 ms frame deadline is independent of that setting.

The GPU lanes require a hardware GL renderer. The report classifies unknown and software renderers explicitly and the command fails for those results. A Linux developer can set `BENCH_ALLOW_SOFTWARE=1` to smoke-test the kit with Mesa. That report identifies its renderer as software. Studio’s room preview uses a separate browser workload.

## Local setup

The launcher uses Git, curl and a JDK 21 or newer. If needed on macOS it downloads a checksum-pinned Temurin JDK and Leiningen into its own cache. The launcher runs in your user account. The show uses the in-memory lighting sink. First setup obtains the pinned repositories and Leiningen dependencies over HTTPS. Repeated runs can reuse them.

Each checkout is individually configurable. Existing checkouts must be at the pinned revision. Additional packed-render commits used in the published Linux comparison are applied in a separate read-only source overlay. No branch in your checkouts is changed.

```sh
TOLGLOW_ROOT=/path/to/tolglow AFTERGLOW_ROOT=/path/to/afterglow ./run.sh all ./results
```

`TOLGLOW_ROOT` is at `fef01db4a5804559f90f82147dd94c7c19bdfa16`. `AFTERGLOW_ROOT` is at `ba73a2b84514b51f8b9d19fd29367e92c6457115`. The overlay source commits are `4769e27c4b803c7a4a9f8ed9cd010ae5ddc0039b`, `c83375f354cfcee7add00f3e4445edbfa870b513` and `902c0e09e002d8fa60de58417f96134d0d57ccca`. Source digests for Afterglow’s beam and field calculations are checked before sampling.

Use `BENCH_CACHE=/path/to/cache` to relocate checkouts, private tools and source overlays. Use `BENCH_OFFLINE=1` once the Git objects, JDK, Leiningen and Maven dependencies are available locally. `BENCH_HEAP` sets the JVM maximum heap (default `2g`). `BENCH_PIXELS`, `BENCH_WARMUP` and `BENCH_SAMPLES` can shorten a shakedown. Record those settings before comparing machines. To rerun only one lane, use `./run.sh cpu new-cpu.edn`, `./run.sh gpu new-gpu.edn` or `./run.sh gpu-show new-gpu-show.edn`.

## Reading the results

Look at `:summary` in `cpu.edn` and `gpu-show.edn` first. Each entry provides the original or changed renderer, frame count, frames completed within 25 ms and median and p95 elapsed, CPU spent sampling the four spheres, and whole-frame allocation. P95 is the 35th-shortest of 36 observations. Timing distributions are independent. The raw `:rows` associate wall time, CPU, allocation, GPU/physical stages and overlapping GC with the same observed frame. Linux-only `:runqueue` is absent on macOS. The two `.jfr` files record GC pause durations.

`gpu.edn` includes verified readback components, measured draw times, bytes per draw, GL renderer and version. In `gpu-show.edn`, `:traffic` records readback byte counts for one additional diagnostic frame and `:backends` records actual native dispatches, draws and fallbacks over the run. `:system` records chip, Mac model identifier, OS version, architecture and Java version. It skips machine names, serial numbers and hardware UUIDs. When sharing results, the three EDN files and `status.tsv` are sufficient. Logs are available locally for diagnosing errors.
