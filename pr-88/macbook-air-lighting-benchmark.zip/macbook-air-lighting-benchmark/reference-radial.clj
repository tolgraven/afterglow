(defn- reference-radial
  "In clear air a radial field is strongest at the nearest point of the beam.
  If a receiver hides that point or the range clips it, use the general probes."
  [{:keys [position axis spread lens-radius-m]} {:keys [center support by-distance]} opts level]
  (let [[px py pz] position [cx cy cz] center [vx vy vz] axis
        px (double px) py (double py) pz (double pz)
        dx (- (double cx) px) dy (- (double cy) py) dz (- (double cz) pz)
        vx (double vx) vy (double vy) vz (double vz)
        z (+ (* dx vx) (* dy vy) (* dz vz))
        rx (- dx (* z vx)) ry (- dy (* z vy)) rz (- dz (* z vz))
        r (Math/sqrt (+ (* rx rx) (* ry ry) (* rz rz)))
        k (double spread) lens (double lens-radius-m)
        in? (and (>= z 0.0) (<= r (+ lens (* k z))))
        ;; Closest point to the side of the infinite frustum in its meridian.
        side-z (max 0.0 (/ (+ z (* k (- r lens))) (+ 1.0 (* k k))))
        side-r (+ lens (* side-z k))
        front-r (min r lens)
        side-gap (if in? 0.0 (Math/hypot (- side-z z) (- side-r r)))
        front-gap (if in? 0.0 (Math/hypot z (- front-r r)))
        face? (< front-gap side-gap)
        gap (if face? front-gap side-gap)]
    (when (<= gap (Math/nextUp (double support)))
      (let [axial (double (cond in? z face? 0.0 :else side-z))
            radial (double (cond in? r face? front-r :else side-r))
            factor (if (pos? r) (/ radial r) 0.0)
            hit (if in? center [(+ px (* axial vx) (* factor rx))
                                (+ py (* axial vy) (* factor ry))
                                (+ pz (* axial vz) (* factor rz))])
            aperture (* factor (/ lens (+ lens (* k axial) 1.0e-300)))
            origin (if (zero? aperture) position [(+ px (* aperture rx)) (+ py (* aperture ry)) (+ pz (* aperture rz))])
            distance (Math/hypot axial (- radial (* aperture r)))
            value (by-distance (min gap (double support)))]
        (cond (not (pos? value)) nil
              (or (> distance (double (:range-m opts)))
                  (when-let [blocked? (:occluded? opts)] (blocked? origin hit distance))) ::probe
              :else {:weight (* level value)})))))

