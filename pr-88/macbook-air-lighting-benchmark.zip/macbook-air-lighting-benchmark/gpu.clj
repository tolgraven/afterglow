(require '[afterglow.render.gpu.expressions :as gpu]
         '[afterglow.render.ir :as ir])
(load-file (System/getenv "BENCH_PLATFORM"))
(require '[lighting-benchmark.platform :as platform])

(def position {:op :vec3 :args (mapv (fn [axis] {:op :position :axis axis}) [:x :y :z])})
(def bias {:op :param :key :bias :type :number})
(def fields {:color {:op :add :args [{:op :multiply :args [position {:op :const :value 0.5}]} bias]}
             :focus {:op :add :args [{:op :position :axis :z} bias]}})

(defn fixture-position [i]
  ;; Dyadic coordinates make this linear GLSL program exactly representable in
  ;; both the float32 feedback buffer and the independent double CPU evaluator.
  [(/ (- (mod i 257) 128) 128.0)
   (/ (- (mod (* i 31) 251) 125) 128.0)
   (/ (- (mod (* i 73) 241) 120) 128.0)])

(defn verify! [reference actual]
  (assert (= (:count reference) (:count actual)) "Fixture count changed")
  (doseq [[key {:keys [values type components]}] (:outputs reference)]
    (let [field (get-in actual [:outputs key])]
      (assert (= [type components] ((juxt :type :components) field)) (str "Field shape changed: " key))
      (when-not (java.util.Arrays/equals ^doubles values ^doubles (:values field))
        (throw (ex-info "GPU values differ from the independent scalar result" {:field key}))))))

(defn checked-draw [runner program positions i]
  (let [inputs {:params {:bias (/ (mod i 255) 256.0)}}
        reference (ir/evaluate-batch program inputs positions)
        t (System/nanoTime)
        measured (gpu/evaluate! runner inputs)
        elapsed (/ (- (System/nanoTime) t) 1e6)]
    (verify! reference measured)
    elapsed))

(let [[output warmup samples] *command-line-args*
      warmup (parse-long warmup) samples (parse-long samples)
      n (parse-long (System/getenv "VENUE_PIXELS"))
      positions (mapv fixture-position (range n))
      program (ir/compile-batch fields)
      system (platform/system)]
  (try
    (with-open [runner (gpu/open! fields positions {:timeout-ms 10000})]
      (let [info (platform/renderer (:resources runner))]
        (try
          (platform/check-renderer! info)
          (catch Exception e
            (spit output (pr-str {:format 1 :mode :gpu :status :unverified-renderer :system system :graphics info}))
            (throw e)))
        (dotimes [i warmup] (checked-draw runner program positions i))
        (let [rows (mapv #(checked-draw runner program positions (+ warmup %)) (range samples))
              result {:format 1 :mode :gpu :status :verified :system system :graphics info
                      :vertices n :fields {:color 3 :focus 1} :readback-bytes-per-draw (* n 4 Float/BYTES)
                      :warmup warmup :samples samples :verified-float-components (* n 4 (+ samples warmup))
                      :timing :dispatch-fence-readback-and-unpack :elapsed-ms (platform/distribution rows)
                      :elapsed-ms-by-draw rows}]
          (spit output (pr-str result))
          (prn (dissoc result :elapsed-ms-by-draw)))))
    (finally (shutdown-agents))))
