#!/usr/bin/env bash
set -euo pipefail
: "${AFTERGLOW_ROOT:?set to an Afterglow checkout at ba73a2b}"
: "${TOLGLOW_ROOT:?set to a Tolglow checkout at fef01db4}"
dir=$(cd "$(dirname "$0")" && pwd)
out=${1:-"$dir/replayed"}
mkdir -p "$out/src/afterglow/render/gpu"
test "$(git -C "$AFTERGLOW_ROOT" rev-parse HEAD)" = ba73a2b84514b51f8b9d19fd29367e92c6457115
test "$(git -C "$TOLGLOW_ROOT" rev-parse HEAD)" = fef01db4a5804559f90f82147dd94c7c19bdfa16
for path in compute fields frame gpu/session hdr; do
  git -C "$AFTERGLOW_ROOT" show "c83375f354cfcee7add00f3e4445edbfa870b513:src/afterglow/render/$path.clj" > "$out/src/afterglow/render/$path.clj"
done
git -C "$AFTERGLOW_ROOT" show 4769e27c4b803c7a4a9f8ed9cd010ae5ddc0039b:src/afterglow/render/presentation.clj > "$out/src/afterglow/render/presentation.clj"
git -C "$AFTERGLOW_ROOT" show 902c0e09e002d8fa60de58417f96134d0d57ccca:src/afterglow/render/layers.clj > "$out/src/afterglow/render/layers.clj"
entries=$(cd "$TOLGLOW_ROOT" && lein with-profile +benchmark,+native-gpu classpath)
bench_cp="$out/src:$entries"
export VENUE_RECEIVER_REFERENCE="$dir/reference-radial.clj" VENUE_MATERIAL_FILE="$dir/mixed-material.clj"
export LIBGL_ALWAYS_SOFTWARE=1 MESA_SHADER_CACHE_DISABLE=true LP_NUM_THREADS=2
export VENUE_GPU_MS=60000 VENUE_MOVEMENT=cpu VENUE_WORKER_MS=5000
java -Xms48m -Xmx180m -XX:ActiveProcessorCount=2 -cp "$bench_cp" clojure.main "$dir/property.clj"
for n in 10000 20000; do
  VENUE_PIXELS=$n java -Xms1450m -Xmx1450m -XX:ActiveProcessorCount=3 -cp "$bench_cp" clojure.main "$dir/paired.clj" "$out/$n.edn" 18 36
done
python3 "$dir/read-rows.py" "$out/10000.edn" "$out/20000.edn"
