import math,io,runpy,sys
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image

base=Path(__file__).resolve().parent
rows=runpy.run_path(str(base/'read-rows.py'))['rows']
runs=[rows(name) for name in sys.argv[1:3]]
sizes=[10000,20000]
n=len(runs[0])//2
on_time=sum(r["ms"] <= 25 for run in runs for r in run)
deadline=f"{on_time} of {sum(map(len,runs))} measured frames met the 25 ms deadline"
target=Path(sys.argv[3])
colors=['#936346','#00736f']
def draw(frame):
    fig,axes=plt.subplots(2,2,figsize=(10.8,6.0),dpi=110,sharex=True)
    fig.subplots_adjust(left=.088,right=.97,top=.72,bottom=.17,hspace=.27,wspace=.20)
    bg='#f8faf7';fig.set_facecolor(bg)
    fig.text(.044,.914,'Sampling four moving spheres',fontsize=21,weight='bold',color='#173d3a')
    fig.text(.044,.848,f'64 moving heads  ·  8 washes  ·  5 room surfaces  ·  {n} measured frame pairs after warmup',fontsize=11,color='#36524c')
    fig.text(.044,.789,'●  Test every room segment',color=colors[0],weight='bold',fontsize=10)
    fig.text(.33,.789,'●  Skip segments inside a clear cell',color=colors[1],weight='bold',fontsize=10)
    for col,run in enumerate(runs):
        for row,(field,label) in enumerate([('field-bytes','Sphere sampling (MB)'),('field-cpu-ms','Sphere sampling CPU (ms)')]):
            ax=axes[row,col]; ax.set_facecolor(bg)
            for s in ('top','right'):ax.spines[s].set_visible(False)
            for s in ('bottom','left'):ax.spines[s].set_color('#bbc7bb')
            if row==0:ax.set_title(f'{sizes[col]:,} pixels · '+('80' if col==0 else '158')+' universes',loc='left',fontsize=12,weight='bold')
            vals=[[r[field]/(1e6 if row==0 else 1) for r in run if r['lane']==lane] for lane in (0,1)]
            top=max(max(v) for v in vals)*1.06
            for j,v in enumerate(vals):
                ax.plot(range(1,frame+1),v[:frame],lw=1.15,color=colors[j])
                ax.scatter([frame],[v[frame-1]],color=colors[j],s=10)
            ax.set_xlim(1,n);ax.set_ylim(0,top);ax.grid(axis='y',color='#e0e7e1')
            ax.tick_params(labelsize=8)
            if not col:ax.set_ylabel(label,fontsize=9)
            if row:ax.set_xlabel('Frame pair',fontsize=9)
    fig.text(.044,.045,deadline+" · CPU values cover the four spheres together",color='#36524c',fontsize=9)
    buf=io.BytesIO();fig.savefig(buf,format='png',facecolor=bg);plt.close(fig);buf.seek(0)
    return Image.open(buf).convert('RGB')
draw(n).save(target.with_suffix('.png'),optimize=True)
frames=[draw(i) for i in sorted(set([1,*range(4,n+1,4),n]))]
frames[0].save(target.with_suffix('.gif'),save_all=True,append_images=frames[1:],duration=[350]*(len(frames)-1)+[1800],loop=0,optimize=True)
