(require '[afterglow.spatial.beam :as beam] '[afterglow.spatial.field :as field] '[tolglow.rig.surfaces :as room])
(binding [*ns* (the-ns 'afterglow.spatial.beam)] (load-file (System/getenv "VENUE_RECEIVER_REFERENCE")))
(let [room (room/receivers {}) random (java.util.Random. 924)
      between (fn [a b] (+ a (* (- b a) (.nextDouble random))))
      xyz (fn [] (mapv (fn [_] (between -14 14)) (range 3)))
      normalized (fn [p] (let [l (Math/hypot (Math/hypot (p 0) (p 1)) (p 2))] (mapv #(/ % l) p)))]
  (doseq [walls [nil room (conj room {:id :tilt :point [0 2 0] :normal [0.01 1 -0.1]})
                 [{:id :middle :point [0 0 0] :normal [2 0 0] :size [1.6 2.1]}]]]
    (let [options (beam/prepare-options {:surfaces walls :range-m 10.1})
          counters (volatile! {})]
      (dotimes [iteration 12000]
        (let [center (if (zero? (mod iteration 5)) [(nth [-6.0 0.0 6.0] (mod iteration 3)) 0.42 -5.0] (xyz))
              radial {:center center :support 4.5 :by-distance (fn [d] (max 0.0 (- 1.0 (/ d 4.5))))}
              fixture {:position (xyz) :axis (normalized (xyz)) :spread (between 0.0 1.0) :lens-radius-m (between 0.0 0.5)}
              outcome (#'beam/reference-radial fixture radial options 0.83)
              candidate (#'beam/radial-beam fixture radial (beam/volume-options options #{:beam} {:center center :radial radial}) 0.83)]
          (assert (= outcome candidate) [iteration walls outcome candidate fixture radial])
          (vswap! counters update (cond (nil? outcome) :miss (map? outcome) :weight :else :probe) (fnil inc 0))))
      (prn :surfaces (count walls) @counters))))
