**0 of 144 measured frames met the 25 ms lighting deadline.** At each rig size, the original and changed renderers each ran 36 measured frames after 18 warmup pairs. The two shows emitted the same state, effect operations, ordered fixture events and ArtDMX bytes at every measured timestamp. Each also completed the same native draw count without a fallback on Mesa software OpenGL.

The following timings use the final revision. The sampling rows cover all four moving spheres together. Each cell shows the original value followed by the changed value. Here p95 is the 35th-shortest of 36 observations.

| Metric per frame | 10,000 pixels and 64 movers | 20,000 pixels and 64 movers |
| --- | ---: | ---: |
| Frames within 25 ms | 0 of 36 → 0 of 36 | 0 of 36 → 0 of 36 |
| Allocation sampling the spheres, median (MB) | 18.37 → 12.82 | 34.75 → 23.64 |
| CPU sampling the spheres, median (ms) | 75 → 71 | 133 → 151 |
| CPU sampling the spheres, p95 (ms) | 270 → 245 | 531 → 281 |
| Whole-frame allocation, median (MB) | 32.28 → 26.57 | 56.68 → 45.48 |
| Complete render and capture, median (ms) | 426 → 393 | 1,163 → 1,182 |
| Complete render and capture, p95 (ms) | 2,831 → 2,867 | 2,826 → 2,321 |

For the specific frames at elapsed p95, the 10,000-pixel run recorded 2,831 ms elapsed with 2,189 ms waiting, then 2,867 ms elapsed with 2,225 ms waiting. The 20,000-pixel run recorded 2,826 ms elapsed with 1,939 ms waiting, then 2,321 ms elapsed with 1,786 ms waiting. Each wait is for the coordinator on shared Linux. CPU work on other threads can overlap it. The complete captures and commands are linked below.
