(require '[afterglow.output.scheduler :as scheduler]
         '[tolglow.bench-show :as bench]
         '[tolglow.perf.admission-cost :as admission]
         '[tolglow.perf.output-deadlines :as replay]
         '[tolglow.show :as show])
(load-file "/tmp/pad-overlap/before-handoff-scheduler.clj")
(require '[afterglow.output.scheduler-baseline :as baseline])

(defn wrap-preparation [host before? injected?]
  (let [{:keys [prepare-output send!]} (:publisher host)
        prepare (fn [universes id]
                  (when (and injected? (pos? id) (zero? (mod id 8)))
                    (java.util.concurrent.locks.LockSupport/parkNanos 32000000))
                  (prepare-output universes id))]
    (if before?
      (update host :publisher assoc :prepare-output nil :send! (fn [u id] (send! (prepare u id) id)))
      (assoc-in host [:publisher :prepare-output] prepare))))

(defn capture [scene {:keys [sender injected?]}]
  (let [before? (= sender :before)
        create show/create-runtime
        start (if before? baseline/start! scheduler/start!)]
    (with-redefs [scheduler/start! start
                  show/create-runtime (fn [options] (wrap-preparation (create options) before? injected?))]
      (let [result (#'replay/run-case :pixel-sculpture scene 120 240 0)]
        (assoc result :sender sender :preparation-stall-ms (if injected? 32 0)
                      :preparation-stall-every-frame-id (when injected? 8))))))

(defn main []
  (let [model (:model (admission/workload 1024 128))
        revisions {:tolglow (bench/revision ".") :afterglow (bench/revision (System/getenv "AFTERGLOW_ROOT"))
                   :baseline-sender "84b3821a27099efdb5cb95c69eba442549523b0e"}
        order [[:before false] [:after false] [:after true] [:before true]
               [:before true] [:after true] [:after false] [:before false]]]
    (with-open [out (clojure.java.io/writer "/tmp/pad-overlap/final-handoff-comparison.edn")]
      (binding [*out* out]
        (println "[")
        (doseq [[sender injected?] order]
          (let [r (capture model {:sender sender :injected? injected?})]
            (prn (assoc r :source-revisions revisions))
            (flush)
            (binding [*out* *err*] (prn (select-keys r [:sender :preparation-stall-ms :summary])))))
        (println "]")))))
(main)
(shutdown-agents)
