import json,statistics,math
d=next(c for c in json.load(open('/tmp/pad-overlap/physical-queue-final.json')) if c['scenario']=='pixel-sculpture' and c['policy']=='measured')
def roundmap(m):return {k:round(v,3) if isinstance(v,float) else v for k,v in m.items()}
rs={r['slot']:r for r in d['renders']}
out={o['slot']:o for o in d['outputs']}
sent=[o for o in d['outputs'] if o.get('sent-at-ms') is not None]
assert len(sent)==len(d['wire']) and all(o['frame-id']==w['id'] for o,w in zip(sent,d['wire']))
wire={o['slot']:w for o,w in zip(sent,d['wire'])}
slots=range(121,361)
def show(i):
 r=rs.get(i); o=out.get(i)
 keys={'slot':i}
 if r:
  due=r['deadline-ms']
  keys.update(lead=r['lead-ms'],wake=r['wake-lag-ms'],lock_to_inputs=r['inputs-at-ms']-r['started-at-ms'],inputs_to_ready=r['ready-at-ms']-r['inputs-at-ms'],ready_to_finish=r['finished-at-ms']-r['ready-at-ms'],cost=r['cost-ms'],slack=r['slack-ms'],prior_job_end_gap=r['started-at-ms']-max([p['finished-at-ms'] for j,p in rs.items() if j<i]+[0]))
 if o:
  keys.update(pubwake=o['started-at-ms']-o['deadline-ms'],source=o.get('frame-id'),pubcost=o['finished-at-ms']-o['started-at-ms'],pack_to_admit=(o['sent-at-ms']-o['started-at-ms']) if o['sent-at-ms'] is not None else None,source_ms=o.get('source-time-ms'),expired=o['expired-before-send?'],callback=(wire[i]['at-ms']-o['deadline-ms']) if i in wire else None)
 return roundmap(keys)
for i in range(137,151): print(show(i))
rr=[r for i,r in rs.items() if i in slots]; oo=[o for i,o in out.items() if i in slots]
print('Summary',roundmap(d['summary']))
print('renders',len(rr),'no-ready',sum(r['ready-at-ms'] is None for r in rr),'on-target',sum(r['slack-ms']>=0 for r in rr),'late',sum(r['slack-ms']<0 for r in rr),'not-planned-or-woken',240-len(rr))
print('pub',len(oo),'current',sum(o['source-time-ms']==o['deadline-ms'] for o in oo),'held',sum(o['source-time-ms'] is not None and o['source-time-ms']!=o['deadline-ms'] for o in oo),'expired',sum(bool(o.get('expired-before-send?')) for o in oo),'no-wake',240-len(oo))
print('Top cost',[(round(r['cost-ms'],3),r['slot']) for r in sorted(rr,key=lambda r:-r['cost-ms'])[:7]])
for r in sorted(rr,key=lambda r:-r['cost-ms'])[:4]:print(show(r['slot']))
print('Top pub',[(round(o['finished-at-ms']-o['started-at-ms'],3),o['slot']) for o in sorted(oo,key=lambda o:o['started-at-ms']-o['finished-at-ms'])[:5]])
for title,rows,func in [('start-inputs',rr,lambda r:r['inputs-at-ms']-r['started-at-ms']),('inputs-ready',rr,lambda r:r['ready-at-ms']-r['inputs-at-ms']),('ready-finish',rr,lambda r:r['finished-at-ms']-r['ready-at-ms']),('wake-lag',rr,lambda r:r['wake-lag-ms']),('pub-wake',oo,lambda o:o['started-at-ms']-o['deadline-ms']),('send-prep',[o for o in oo if o['sent-at-ms'] is not None],lambda o:o['sent-at-ms']-o['started-at-ms']),('send-callback',[o for o in oo if o['sent-at-ms'] is not None],lambda o:o['sent-by-ms']-o['sent-at-ms'])]:
 a=sorted(map(func,rows)); print(title,len(a),[round(a[math.ceil(p*len(a))-1],3) for p in [0.5,.95,1]])
c=next(q for q in json.load(open('/tmp/pad-overlap/physical-queue-final.json')) if q['scenario']=='eight-movers' and q['policy']=='measured-extra-reserve')
for o,w in zip([o for o in c['outputs'] if o['sent-at-ms'] is not None],c['wire']):
 if 120<o['slot']<=360 and w['at-ms']>=o['deadline-ms']+25:
  print('sink miss',o['slot'],o['sent-at-ms']-o['deadline-ms'],w['at-ms']-o['deadline-ms'],w['at-ms']-o['sent-at-ms'])
