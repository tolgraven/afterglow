# Physical output captures

The original screenshot used the measured pixel-sculpture case from
physical-queue-final.edn. It runs 1,024 RGBW pixels and 128 moving heads at
40 Hz. Slots 121–360 are the six measured seconds. The final source checks
refer to the timestamps inside the capture sink. The original image is
original-physical-slot-chart.png.

The eight sequential runs in final-handoff-comparison.edn reuse the same
model with two workers. The first and last pair have ordinary preparation.
The middle pairs inject a 32 ms wait during final fixture preparation on
every eighth frame ID. They alternate the baseline and updated publisher,
reversing the order on the second run. The machine was shared with other
processes. The benchmark JVM was pinned to logical CPUs 0–2. Hardware was
disconnected. The archive contains source revisions and actual raw transport
receipts.

To reproduce the original comparison on Linux, use Tolglow 9ba18b3f and
Afterglow 74d0de46, put the included compare-final-handoff.clj and
before-handoff-scheduler.clj in /tmp/pad-overlap and run this from Tolglow.

```sh
AFTERGLOW_ROOT=../afterglow taskset -c 0-2 lein with-profile +benchmark run \
  -m clojure.main /tmp/pad-overlap/compare-final-handoff.clj
```

The baseline namespace is the source of
afterglow.output.scheduler at 84b3821a27099efdb5cb95c69eba442549523b0e
with a different namespace name. The newer runtime supplies the same host
model and packet-preparation functions to all cases. In the baseline cases
fixture preparation happens inside the transport wrapper, after the deadline
check. In the updated cases it happens before the deadline check. Both
schedulers use the same monotonic clock and physical capture sink.

The reported current-source metric in older files compares the packet's
source deadline with the selected nominal slot. To require delivery within
that actual slot, pair each successful publisher row with its corresponding
wire row and test that the wire timestamp is earlier than the next
nominal deadline. Newer Tolglow records both counts.
